"""
Streamlit Dashboard – AI Disaster Response System

Features:
  - Scenario selector
  - Live map with GeoJSON (folium)
  - Agent decision panel
  - Metrics display with charts
  - SITREP export
  - Timeline replay
"""
import sys
import os
import json
import datetime

import streamlit as st
import folium
from streamlit_folium import st_folium
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd

# Path setup
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from backend.simulation.runner import SimulationRunner
from backend.synthetic.engine import SCENARIO_CONFIGS

# ── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="🌊 AI Disaster Response System",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Styling ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
[data-testid="stMetricValue"] { font-size: 1.6rem; font-weight: 700; }
.agent-card {
    background: #1e2a3a; border-radius: 8px; padding: 12px;
    margin-bottom: 10px; border-left: 4px solid #4a9eff;
}
.critical-badge { background: #c0392b; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.8rem; }
.moderate-badge { background: #e67e22; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.8rem; }
.low-badge      { background: #27ae60; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.8rem; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/flood.png", width=80)
    st.title("🌊 Disaster Response")
    st.markdown("**AI-Powered Emergency Management**")
    st.divider()

    scenario_options = {k: f"{k}: {v['name']}" for k, v in SCENARIO_CONFIGS.items()}
    selected_scenario = st.selectbox(
        "📋 Select Scenario",
        options=list(scenario_options.keys()),
        format_func=lambda k: scenario_options[k],
        index=2,  # S3 default
    )
    seed = st.number_input("🎲 Random Seed", value=42, min_value=1, max_value=9999)

    run_btn = st.button("▶ Run Simulation", type="primary", use_container_width=True)
    st.divider()

    st.markdown("### 📚 Scenarios")
    for k, v in SCENARIO_CONFIGS.items():
        badge = "🔴" if k in ("S2", "S5") else "🟡" if k in ("S3", "S6") else "🟢"
        st.markdown(f"{badge} **{k}** – {v['name']}")

    st.divider()
    st.caption("Capstone Project · AI Disaster Response · 2024")


# ── Cache / State ─────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def run_simulation(scenario: str, seed: int):
    runner = SimulationRunner()
    result = runner.run(scenario=scenario, seed=seed)
    return result.to_dict()


# ── Header ────────────────────────────────────────────────────────────────────
st.title("🌊 AI-Driven Disaster Response System")
st.markdown(
    "An end-to-end AI-powered emergency response simulation using multi-modal data fusion, "
    "deterministic planning, and multi-agent orchestration."
)

# ── Run ───────────────────────────────────────────────────────────────────────
if run_btn or "sim_data" not in st.session_state or st.session_state.get("last_scenario") != (selected_scenario, seed):
    with st.spinner(f"🔄 Running simulation for scenario **{selected_scenario}**…"):
        st.session_state["sim_data"] = run_simulation(selected_scenario, seed)
        st.session_state["last_scenario"] = (selected_scenario, seed)

data = st.session_state.get("sim_data")
if not data:
    st.info("👈 Select a scenario and click **Run Simulation** to begin.")
    st.stop()

fe    = data["flood_event"]
plan  = data["dispatch_plan"]
sitrep = data["sitrep"]
metrics = data["metrics"]
timeline = data.get("timeline", [])


# ── Top KPIs ──────────────────────────────────────────────────────────────────
st.divider()
c1, c2, c3, c4, c5, c6 = st.columns(6)
sev_color = {"LOW":"🟢","MODERATE":"🟡","HIGH":"🟠","SEVERE":"🔴","EXTREME":"🆘"}
c1.metric("Severity",       f"{sev_color.get(fe['severity'], '⚠')} {fe['severity']}")
c2.metric("Confidence",     f"{fe['confidence']:.0%}")
c3.metric("Risk Score",     f"{fe['risk_score']:.1f}/10")
c4.metric("People Affected",f"{fe['estimated_affected_people']:,}")
c5.metric("Cases",          plan['total_cases'])
c6.metric("Overall Score",  f"{metrics['overall_score']:.0f}/100")
st.divider()


# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_map, tab_cases, tab_agents, tab_metrics, tab_sitrep, tab_timeline = st.tabs([
    "🗺 Map", "📋 Cases & Resources", "🤖 Agent Decisions",
    "📊 Metrics", "📣 SITREP", "⏱ Timeline"
])


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1: MAP
# ═══════════════════════════════════════════════════════════════════════════════
with tab_map:
    st.subheader("🗺 Affected Area & Distress Reports")

    epicenter = fe["epicenter"]
    m = folium.Map(
        location=[epicenter["lat"], epicenter["lon"]],
        zoom_start=12,
        tiles="CartoDB dark_matter",
    )

    # Add GeoJSON layers
    geojson_data = fe["affected_area_geojson"]
    for feat in geojson_data.get("features", []):
        ftype = feat.get("properties", {}).get("type", "")
        geom = feat.get("geometry", {})

        if geom.get("type") == "Polygon":
            if ftype == "satellite_flood_zone":
                folium.GeoJson(
                    feat,
                    style_function=lambda f: {
                        "fillColor": "#3498db", "color": "#2980b9",
                        "weight": 2, "fillOpacity": 0.35,
                    },
                    tooltip="Satellite Flood Zone",
                ).add_to(m)
            elif ftype == "estimated_flood_extent":
                folium.GeoJson(
                    feat,
                    style_function=lambda f: {
                        "fillColor": "#e74c3c", "color": "#c0392b",
                        "weight": 2, "fillOpacity": 0.15,
                        "dashArray": "5 5",
                    },
                    tooltip=f"Estimated Flood Extent (conf: {feat['properties'].get('confidence',0):.0%})",
                ).add_to(m)

        elif geom.get("type") == "Point":
            coords = geom["coordinates"]
            props  = feat.get("properties", {})
            sev    = props.get("severity", 1)
            color  = ["green","yellow","orange","red","darkred"][min(sev-1,4)]
            folium.CircleMarker(
                location=[coords[1], coords[0]],
                radius=6 + props.get("num_people", 1),
                color=color,
                fill=True,
                fill_opacity=0.8,
                tooltip=f"{props.get('report_id','?')} | Sev {sev} | {props.get('num_people',1)} ppl | {props.get('message','')[:60]}",
            ).add_to(m)

    # Add shelters
    for s in plan["shelters"]:
        folium.Marker(
            location=[s["location"]["lat"], s["location"]["lon"]],
            tooltip=f"🏠 {s['name']} (cap {s['capacity']})",
            icon=folium.Icon(color="blue", icon="home", prefix="fa"),
        ).add_to(m)

    # Epicenter marker
    folium.Marker(
        location=[epicenter["lat"], epicenter["lon"]],
        tooltip="📍 Flood Epicenter",
        icon=folium.Icon(color="red", icon="exclamation-triangle", prefix="fa"),
    ).add_to(m)

    # Legend
    legend = """
    <div style='position:fixed;bottom:40px;left:40px;z-index:1000;background:rgba(0,0,0,0.75);
                padding:12px 16px;border-radius:8px;color:white;font-size:13px;'>
        <b>Legend</b><br>
        🔵 Satellite flood zone<br>
        🔴 Estimated extent<br>
        🟢🟡🟠🔴 Distress reports (severity)<br>
        🏠 Shelter sites<br>
        📍 Epicenter
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend))

    st_folium(m, height=550, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2: CASES & RESOURCES
# ═══════════════════════════════════════════════════════════════════════════════
with tab_cases:
    col_l, col_r = st.columns(2)

    with col_l:
        st.subheader("📋 Distress Cases")
        cases_df = pd.DataFrame([
            {
                "Case ID":  c["case_id"],
                "Urgency":  c["urgency_score"],
                "People":   c["num_people"],
                "Medical":  "🏥" if c["medical_need"] else "",
                "Cluster":  c.get("cluster_id", "-"),
                "Resource": c.get("assigned_resource") or "unassigned",
                "ETA (min)":c.get("eta_minutes") or "—",
            }
            for c in plan["cases"]
        ])
        st.dataframe(
            cases_df.style.background_gradient(subset=["Urgency"], cmap="RdYlGn_r"),
            use_container_width=True, height=400,
        )

    with col_r:
        st.subheader("🚒 Resources Deployed")
        res_df = pd.DataFrame([
            {
                "Unit ID": r["unit_id"],
                "Type":    r["resource_type"],
                "Status":  "✅ Available" if r["available"] else "🔴 Assigned",
                "Assigned Cases": len(r["assigned_cases"]),
                "Capacity": r["capacity"],
            }
            for r in plan["resources"]
        ])
        st.dataframe(res_df, use_container_width=True, height=400)

    # Urgency distribution chart
    st.subheader("📈 Urgency Score Distribution")
    urgency_vals = [c["urgency_score"] for c in plan["cases"]]
    fig = px.histogram(
        x=urgency_vals, nbins=10, color_discrete_sequence=["#e74c3c"],
        labels={"x": "Urgency Score", "count": "Cases"},
        title="Distribution of Urgency Scores",
    )
    fig.update_layout(template="plotly_dark", height=300)
    st.plotly_chart(fig, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3: AGENT DECISIONS
# ═══════════════════════════════════════════════════════════════════════════════
with tab_agents:
    st.subheader("🤖 Multi-Agent Decision Log")
    st.caption("Each agent processes inputs and produces explainable outputs.")

    agent_icons = {
        "triage":   "🚨", "cluster": "📍", "resource": "🚒",
        "routing":  "🗺",  "medical": "🏥", "command":  "📣",
    }

    for dec in sitrep["agent_decisions"]:
        icon = agent_icons.get(dec["agent"], "🤖")
        with st.expander(f"{icon} **{dec['agent'].upper()} AGENT** — {dec['output_summary']}", expanded=False):
            col1, col2 = st.columns(2)
            col1.markdown(f"**Input:** {dec['input_summary']}")
            col2.markdown(f"**Output:** {dec['output_summary']}")
            st.markdown("**Reasoning:**")
            st.info(dec["reasoning"])
            if dec.get("data"):
                st.json(dec["data"])


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4: METRICS
# ═══════════════════════════════════════════════════════════════════════════════
with tab_metrics:
    st.subheader("📊 Evaluation Metrics")
    st.caption(metrics.get("notes", ""))

    m1, m2, m3 = st.columns(3)
    m1.metric("Detection Precision", f"{metrics['detection_precision']:.0%}")
    m2.metric("Detection Recall",    f"{metrics['detection_recall']:.0%}")
    m3.metric("Urgent Coverage",     f"{metrics['urgent_case_coverage_pct']:.1f}%")

    m4, m5, m6 = st.columns(3)
    m4.metric("Avg Response Time",   f"{metrics['avg_response_time_min']:.1f} min")
    m5.metric("Resource Utilisation",f"{metrics['resource_utilization_rate']:.1f}%")
    m6.metric("Route Safety",        f"{metrics['route_safety_score']:.2f}")

    st.divider()
    col_gauge, col_radar = st.columns(2)

    with col_gauge:
        fig_gauge = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=metrics["overall_score"],
            delta={"reference": 70},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "#4a9eff"},
                "steps": [
                    {"range": [0,  40], "color": "#e74c3c"},
                    {"range": [40, 70], "color": "#f39c12"},
                    {"range": [70,100], "color": "#27ae60"},
                ],
                "threshold": {"line": {"color": "white", "width": 2}, "value": 70},
            },
            title={"text": "Overall Response Score"},
            number={"suffix": "/100"},
        ))
        fig_gauge.update_layout(template="plotly_dark", height=300)
        st.plotly_chart(fig_gauge, use_container_width=True)

    with col_radar:
        categories = ["Precision","Recall","Urgent\nCoverage","Resource\nUtil","Route\nSafety","Fairness"]
        values = [
            metrics["detection_precision"],
            metrics["detection_recall"],
            metrics["urgent_case_coverage_pct"] / 100,
            metrics["resource_utilization_rate"] / 100,
            metrics["route_safety_score"],
            metrics["fairness_distribution_score"],
        ]
        fig_radar = go.Figure(go.Scatterpolar(
            r=values + [values[0]],
            theta=categories + [categories[0]],
            fill="toself",
            fillcolor="rgba(74,158,255,0.3)",
            line=dict(color="#4a9eff", width=2),
        ))
        fig_radar.update_layout(
            template="plotly_dark",
            polar=dict(radialaxis=dict(range=[0, 1])),
            title="Performance Radar",
            height=300,
        )
        st.plotly_chart(fig_radar, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 5: SITREP
# ═══════════════════════════════════════════════════════════════════════════════
with tab_sitrep:
    st.subheader("📣 Situation Report (SITREP)")

    status_color = "🟢" if sitrep["status"] == "RESOLVED" else "🔴"
    st.markdown(f"**Status:** {status_color} {sitrep['status']}")

    st.markdown("### Narrative")
    st.success(sitrep["narrative"])

    st.markdown("### Operational Recommendations")
    for i, rec in enumerate(sitrep["recommendations"], 1):
        st.markdown(f"**{i}.** {rec}")

    st.divider()
    # Evidence
    st.markdown("### Detection Evidence")
    for i, ev in enumerate(fe["evidence"], 1):
        st.info(f"**[{i}]** {ev}")

    # Export buttons
    st.divider()
    col_j, col_s = st.columns(2)
    sitrep_export = {
        "sitrep_id": sitrep.get("sitrep_id"),
        "generated_at": str(datetime.datetime.now()),
        "scenario": fe["scenario"],
        "severity": fe["severity"],
        "confidence": fe["confidence"],
        "status": sitrep["status"],
        "narrative": sitrep["narrative"],
        "recommendations": sitrep["recommendations"],
        "evidence": fe["evidence"],
        "metrics": metrics,
    }
    col_j.download_button(
        "⬇ Export SITREP (JSON)",
        data=json.dumps(sitrep_export, indent=2),
        file_name=f"SITREP_{fe['scenario']}_{fe['event_id']}.json",
        mime="application/json",
        use_container_width=True,
    )
    full_json = json.dumps(data, indent=2, default=str)
    col_s.download_button(
        "⬇ Export Full Results (JSON)",
        data=full_json,
        file_name=f"full_{fe['scenario']}_{fe['event_id']}.json",
        mime="application/json",
        use_container_width=True,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 6: TIMELINE
# ═══════════════════════════════════════════════════════════════════════════════
with tab_timeline:
    st.subheader("⏱ Simulation Timeline Replay")

    if timeline:
        df_tl = pd.DataFrame(
            [(label, ts) for label, ts in timeline],
            columns=["Step", "Timestamp"],
        )
        df_tl["Timestamp"] = pd.to_datetime(df_tl["Timestamp"])
        df_tl["Elapsed (s)"] = (df_tl["Timestamp"] - df_tl["Timestamp"].iloc[0]).dt.total_seconds()

        fig_tl = px.timeline(
            df_tl.assign(Start=df_tl["Timestamp"], Finish=df_tl["Timestamp"] + pd.Timedelta(milliseconds=200)),
            x_start="Start", x_end="Finish", y="Step",
            color="Step", color_discrete_sequence=px.colors.qualitative.Bold,
            title="Pipeline Execution Steps",
        )
        fig_tl.update_layout(template="plotly_dark", height=350, showlegend=False)
        st.plotly_chart(fig_tl, use_container_width=True)

        st.dataframe(df_tl[["Step", "Elapsed (s)"]], use_container_width=True)

    else:
        st.info("Timeline data unavailable for this run.")

    # Scenario comparison
    st.subheader("🔄 Run All Scenarios (Comparison)")
    if st.button("🚀 Compare All Scenarios", use_container_width=True):
        comparison_data = []
        progress = st.progress(0)
        for i, sc in enumerate(SCENARIO_CONFIGS):
            with st.spinner(f"Running {sc}…"):
                d = run_simulation(sc, seed)
                comparison_data.append({
                    "Scenario": d["metrics"]["scenario"],
                    "Overall Score": d["metrics"]["overall_score"],
                    "Precision": d["metrics"]["detection_precision"],
                    "Recall":    d["metrics"]["detection_recall"],
                    "Urgent Coverage %": d["metrics"]["urgent_case_coverage_pct"],
                    "Avg ETA (min)": d["metrics"]["avg_response_time_min"],
                    "Resource Util %": d["metrics"]["resource_utilization_rate"],
                })
            progress.progress((i + 1) / len(SCENARIO_CONFIGS))

        df_comp = pd.DataFrame(comparison_data)
        st.dataframe(
            df_comp.style.background_gradient(subset=["Overall Score"], cmap="RdYlGn"),
            use_container_width=True,
        )

        fig_comp = px.bar(
            df_comp, x="Scenario", y="Overall Score",
            color="Overall Score",
            color_continuous_scale="RdYlGn",
            title="Overall Response Score by Scenario",
            range_color=[0, 100],
        )
        fig_comp.update_layout(template="plotly_dark", height=400)
        st.plotly_chart(fig_comp, use_container_width=True)


# ── Footer ────────────────────────────────────────────────────────────────────
st.divider()
st.caption(
    "🌊 AI-Driven Disaster Response System · Capstone Project · "
    "Decision support tool — not a replacement for emergency authorities."
)

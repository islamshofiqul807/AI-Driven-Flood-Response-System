FLOOD EMERGENCY RESPONSE KNOWLEDGE BASE
========================================

## 1. Triage Protocols

### Priority Levels
- **P1 (Immediate)**: Life-threatening conditions; trapped victims, medical emergencies, children/elderly in rising water. Respond within 15 minutes.
- **P2 (Urgent)**: Significant risk but stable; isolated families, stranded vehicles, loss of utilities. Respond within 45 minutes.
- **P3 (Delayed)**: Low immediate risk; property protection, supply distribution. Respond within 2 hours.

### Medical Triage in Floods
- Hypothermia risk increases after 30 minutes in floodwater
- Contaminated water causes leptospirosis, typhoid, cholera
- Electrical hazards near submerged infrastructure
- Diabetic and cardiac patients require priority dispatch

---

## 2. Resource Allocation Standards

### Rescue Boats
- Capacity: 6–10 persons per trip
- Deploy in: water depth > 0.5 m on roads
- Speed: ~20–30 km/h in calm floodwater
- Requirement: 1 boat per 50 affected persons minimum

### Helicopters
- Best for: Rooftop rescues, remote areas, mass casualty
- Capacity: 8–15 persons
- Limited by: Weather (wind > 60 km/h = grounded), fuel range

### Ambulances
- Priority to: Medical emergencies, elderly, disabled
- Limitation: Cannot operate in water > 30 cm depth

### Supply Trucks
- For: Food, water, medicine distribution to shelters
- Operate on: Roads with < 20 cm water depth only

---

## 3. Shelter Management

### Site Selection Criteria
- Elevation > 5 m above flood plain
- Accessible road connectivity
- Minimum 3 sq m per displaced person
- Proximity to medical facilities

### Minimum Requirements per Shelter
- 20 litres of clean water per person per day
- 2,100 kcal food per person per day
- Separate sanitation facilities
- Medical station for > 100 person shelters

---

## 4. Communication Protocols

### Alert Cascade
1. Command Centre activation
2. Resource depot notification
3. Field unit deployment orders
4. Public broadcast (radio, SMS, loudspeaker)
5. Hospital and medical standby

### SITREP Format
- Situation summary (2–3 sentences)
- Current resources deployed
- Coverage status
- Immediate recommendations
- Next update time

---

## 5. Route Planning Rules

### Road Impassability Thresholds
- Cars: > 30 cm water depth
- Trucks: > 50 cm water depth
- Boats required: > 60 cm water depth
- Helicopters only: > 1.5 m water depth

### Hazard Assessment Factors
- Distance from river banks (flood wave risk)
- Bridge structural integrity
- Power line proximity (electrocution risk)
- Road surface erosion likelihood

---

## 6. Scenario-Specific Protocols

### Flash Flood (S2)
- Issue immediate public warning
- Activate all rescue boats simultaneously
- Pre-position helicopters at elevated staging areas
- Evacuate low-lying areas proactively

### River Flood / Slow Expansion (S3)
- Phased evacuation starting from lowest zones
- Monitor river gauge stations every hour
- Establish supply chains to cut-off communities
- Plan 72-hour sustained operations

### Medical Emergency Heavy (S5)
- Activate hospital surge capacity
- Deploy medical teams with rescue units
- Establish field hospital at largest shelter
- Helicopter priority for critical patients

### Misinformation Scenario (S4)
- Cross-verify reports with satellite and sensor data
- Deploy assessment teams before full resource activation
- Issue public clarifications to prevent panic
- Maintain readiness without full deployment

---

## 7. Evaluation Benchmarks

| Metric                    | Excellent | Acceptable | Poor    |
|---------------------------|-----------|------------|---------|
| Detection Precision       | > 0.85    | 0.65–0.85  | < 0.65  |
| Detection Recall          | > 0.85    | 0.65–0.85  | < 0.65  |
| Urgent Case Coverage      | > 90%     | 70–90%     | < 70%   |
| Avg Response Time         | < 30 min  | 30–60 min  | > 60 min|
| Resource Utilisation      | 70–90%    | 50–70%     | < 50%   |
| Route Safety Score        | > 0.80    | 0.60–0.80  | < 0.60  |
| Fairness Distribution     | > 0.85    | 0.70–0.85  | < 0.70  |

RESCUE TEAM PROTOCOLS
=====================

## Team Types and Capabilities

### Boat Teams
- Operate in: water depth 0.5m – 3m
- Capacity: 4-8 rescued persons per trip
- Speed: ~25 km/h in calm water
- Equipment: life vests, ropes, first aid kit
- Best for: flooded streets, river rescues, isolated houses

### Helicopter Units
- Operate in: all flood depths, remote/inaccessible areas
- Capacity: 3-15 persons per sortie
- Speed: ~120 km/h
- Equipment: winch, rescue basket, medical kit
- Best for: rooftop rescues, large groups, critical medical

### Medical Response Teams
- Primary role: trauma and emergency care in field
- Capacity: treat 5-10 patients per hour
- Equipment: defibrillator, IV supplies, oxygen, stretchers
- Best for: medical emergencies, elderly, children, maternity

### Ground Units
- Operate in: water depth < 0.3m (passable roads)
- Capacity: 6-10 persons
- Equipment: generators, water purification, emergency rations
- Best for: evacuation support, supply delivery, search teams

## Status Lifecycle

1. STANDBY – at depot, ready to deploy within 5 minutes
2. EN ROUTE – travelling to assigned case location
3. ON SCENE – actively conducting rescue/medical operations
4. RETURNING – heading back to depot or next assignment

## Dispatch Priority Rules

1. Severity 5 (extreme): helicopter or medical first
2. Medical need flagged: medical team mandatory
3. Group size > 8: helicopter preferred
4. Water depth > 1m: boat teams only
5. Accessible road: ground unit acceptable
6. Multiple teams per case: allowed for mass casualty

## Communication Protocol

- Each team checks in every 15 minutes when deployed
- Status update required on: arrival, patient contact, departure
- Medical emergencies escalate immediately to command
- Helicopter priority clearance required if wind > 50 km/h

## Coverage Targets

- 100% of severity-4/5 cases within 20 minutes
- 90% of all cases with assigned team
- Medical team present at every cluster with medical cases
- No cluster without at least one active team

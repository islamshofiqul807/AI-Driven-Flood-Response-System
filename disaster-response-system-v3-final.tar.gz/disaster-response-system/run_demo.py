#!/usr/bin/env python3
"""
run_demo.py – CLI entry point for the AI Disaster Response System

Usage:
    python run_demo.py --scenario S3 --seed 42
    python run_demo.py --scenario S2 --seed 7 --output results.json
    python run_demo.py --all          # run all 6 scenarios and compare
"""
import argparse
import sys
import os
import json

sys.path.insert(0, os.path.dirname(__file__))

from backend.simulation.runner import SimulationRunner
from backend.synthetic.engine import SCENARIO_CONFIGS

SCENARIOS_HELP = "\n".join(f"  {k}: {v['name']}" for k, v in SCENARIO_CONFIGS.items())

STATUS_BADGE = {
    "standby":   "[ STANDBY ]",
    "en_route":  "[EN ROUTE ]",
    "on_scene":  "[ON SCENE ]",
    "returning": "[RETURNING]",
}

TEAM_TYPE_LABEL = {
    "boat":       "Boat      ",
    "helicopter": "Helicopter",
    "medical":    "Medical   ",
    "ground":     "Ground    ",
}


def print_section(title: str):
    print(f"\n{'═'*70}")
    print(f"  {title}")
    print(f"{'═'*70}")


def print_kv(key: str, value, indent: int = 2):
    print(f"{' '*indent}{key:<35} {value}")


def run_and_display(scenario: str, seed: int, output: str | None):
    runner = SimulationRunner()

    print(f"\n🌊  AI-Driven Disaster Response System")
    print(f"    Scenario : {scenario} – {SCENARIO_CONFIGS[scenario]['name']}")
    print(f"    Seed     : {seed}")

    result = runner.run(scenario=scenario, seed=seed)

    # ── Flood Event ───────────────────────────────────────────────────────────
    fe = result.flood_event
    print_section("🔍 FLOOD DETECTION RESULT")
    print_kv("Event ID",            fe.event_id)
    print_kv("Severity",            f"{fe.severity.name} ({fe.severity.value}/5)")
    print_kv("Confidence",          f"{fe.confidence:.1%}")
    print_kv("Risk Score",          f"{fe.risk_score:.1f}/10")
    print_kv("Estimated Affected",  f"{fe.estimated_affected_people} people")
    print_kv("Active",              str(fe.active))
    print_kv("Epicenter",           f"Lat {fe.epicenter['lat']:.4f}  Lon {fe.epicenter['lon']:.4f}")
    print(f"\n  Evidence:")
    for i, ev in enumerate(fe.evidence, 1):
        print(f"    [{i}] {ev}")

    # ── Dispatch Plan ─────────────────────────────────────────────────────────
    plan = result.dispatch_plan
    print_section("📋 DISPATCH PLAN")
    print_kv("Plan ID",             plan.plan_id)
    print_kv("Total Cases",         plan.total_cases)
    print_kv("High-Urgency Cases",  plan.high_urgency_cases)
    print_kv("Resources Deployed",  len(plan.resources))
    print_kv("Shelters Activated",  len(plan.shelters))
    print_kv("Route Segments",      len(plan.routes))

    print(f"\n  Top 5 Cases by Urgency:")
    for c in plan.cases[:5]:
        med = "🏥" if c.medical_need else "  "
        print(f"    {med} {c.case_id:20s}  urgency={c.urgency_score:4.1f}  "
              f"people={c.num_people:2d}  cluster={c.cluster_id}  "
              f"ETA={str(c.eta_minutes or '?'):>5} min  → {c.assigned_resource or 'unassigned'}")

    # ── Rescue Teams ──────────────────────────────────────────────────────────
    sitrep = result.sitrep
    rescue_assignments = sitrep.rescue_assignments
    rescue_teams       = sitrep.rescue_teams

    print_section("🚨 RESCUE TEAM AUTO-ASSIGNMENT")

    if not fe.active:
        print("  ⚠  Flood not active — all rescue teams remain on STANDBY.")
        for t in rescue_teams:
            print(f"    {STATUS_BADGE['standby']}  {t['name']}")
    else:
        on_scene  = sum(1 for a in rescue_assignments if a["status"] == "on_scene")
        en_route  = sum(1 for a in rescue_assignments if a["status"] == "en_route")
        standby_n = sum(1 for t in rescue_teams       if t["status"]  == "standby")
        med_teams = sum(1 for a in rescue_assignments  if a["team"]["team_type"] == "medical")

        print(f"  Teams dispatched : {len(rescue_assignments)}")
        print(f"  On scene         : {on_scene}")
        print(f"  En route         : {en_route}")
        print(f"  Standby (reserve): {standby_n}")
        print(f"  Medical teams    : {med_teams}")
        print()

        if rescue_assignments:
            print(f"  {'BADGE':<12} {'TEAM':<26} {'TYPE':<12} "
                  f"{'CASE':<20} {'ETA':>6}  NOTES")
            print(f"  {'─'*10:<12} {'─'*24:<26} {'─'*10:<12} "
                  f"{'─'*18:<20} {'─'*5:>6}  {'─'*20}")
            for a in rescue_assignments:
                team   = a["team"]
                badge  = STATUS_BADGE.get(a["status"], "[       ]")
                ttype  = TEAM_TYPE_LABEL.get(team["team_type"], team["team_type"])
                eta    = f"{team.get('eta_minutes', '?')} min"
                notes  = a["notes"][:40]
                print(f"  {badge:<12} {team['name']:<26} {ttype:<12} "
                      f"{a['case_id']:<20} {eta:>8}  {notes}")

        unassigned = plan.total_cases - len(rescue_assignments)
        if unassigned > 0:
            print(f"\n  ⚠  {unassigned} case(s) without a rescue team — "
                  "consider activating reserve units.")
        else:
            print(f"\n  ✅  All {plan.total_cases} distress cases have an assigned rescue team.")

    # ── SITREP ────────────────────────────────────────────────────────────────
    print_section("📣 SITUATION REPORT (SITREP)")
    print(f"  Status: {sitrep.status}")
    print(f"\n  Narrative:\n  {sitrep.narrative}\n")
    print("  Recommendations:")
    for i, rec in enumerate(sitrep.recommendations, 1):
        print(f"    {i}. {rec}")

    # ── Agent Decisions ───────────────────────────────────────────────────────
    print_section("🤖 AGENT DECISION LOG")
    for dec in sitrep.agent_decisions:
        print(f"\n  [{dec.agent.value.upper():10s}] {dec.output_summary}")
        print(f"  {'':12s} {dec.reasoning[:120]}{'…' if len(dec.reasoning) > 120 else ''}")

    # ── Evaluation Metrics ────────────────────────────────────────────────────
    m = result.metrics
    print_section("📊 EVALUATION METRICS")
    print_kv("Scenario",              m.scenario)
    print_kv("Detection Precision",   f"{m.detection_precision:.2%}")
    print_kv("Detection Recall",      f"{m.detection_recall:.2%}")
    print_kv("Urgent Case Coverage",  f"{m.urgent_case_coverage_pct:.1f}%")
    print_kv("Avg Response Time",     f"{m.avg_response_time_min:.1f} min")
    print_kv("Resource Utilisation",  f"{m.resource_utilization_rate:.1f}%")
    print_kv("Route Safety Score",    f"{m.route_safety_score:.2f}")
    print_kv("Fairness Distribution", f"{m.fairness_distribution_score:.2f}")
    rescue_cov = (len(rescue_assignments) / max(plan.total_cases, 1)) * 100
    print_kv("Rescue Coverage",       f"{rescue_cov:.0f}%  ({len(rescue_assignments)}/{plan.total_cases} cases)")
    print(f"\n  {'OVERALL SCORE':35s} {m.overall_score:.1f} / 100\n")

    # ── Timeline ──────────────────────────────────────────────────────────────
    print_section("⏱  SIMULATION TIMELINE")
    for label, ts in result.timeline:
        print(f"  {str(ts)[11:19]}  {label}")

    # ── Output ────────────────────────────────────────────────────────────────
    if output:
        with open(output, "w") as f:
            json.dump(result.to_dict(), f, indent=2, default=str)
        print(f"\n✅  Full results saved to: {output}")

    print(f"\n{'─'*70}\n")


def run_all_scenarios(seed: int):
    """Run and compare all 6 scenarios."""
    runner = SimulationRunner()
    print(f"\n🌊  AI Disaster Response – All Scenarios Comparison  (seed={seed})")
    print(f"{'═'*90}")
    print(f"  {'Scenario':<28}  {'Sev':>5}  {'Conf':>6}  {'Score':>6}  "
          f"{'Cases':>5}  {'Dispatched':>10}  {'OnScene':>7}  {'EnRoute':>7}")
    print(f"  {'─'*26:<28}  {'─'*5:>5}  {'─'*6:>6}  {'─'*5:>6}  "
          f"{'─'*5:>5}  {'─'*10:>10}  {'─'*7:>7}  {'─'*7:>7}")

    for sc in SCENARIO_CONFIGS:
        r = runner.run(sc, seed)
        asgns    = r.sitrep.rescue_assignments
        on_scene = sum(1 for a in asgns if a["status"] == "on_scene")
        en_route = sum(1 for a in asgns if a["status"] == "en_route")
        name     = SCENARIO_CONFIGS[sc]['name'][:26]
        print(f"  {sc}: {name:<24}  {r.flood_event.severity.name:>5}  "
              f"{r.flood_event.confidence:>5.0%}  "
              f"{r.metrics.overall_score:>5.1f}  "
              f"{r.dispatch_plan.total_cases:>5}  "
              f"{len(asgns):>10}  {on_scene:>7}  {en_route:>7}")
    print(f"{'═'*90}\n")


def main():
    parser = argparse.ArgumentParser(
        description="AI Disaster Response System – CLI Demo",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=f"Available scenarios:\n{SCENARIOS_HELP}",
    )
    parser.add_argument("--scenario", default="S3",
                        help="Scenario ID (default: S3)")
    parser.add_argument("--seed",     type=int, default=42,
                        help="Random seed (default: 42)")
    parser.add_argument("--output",   default=None,
                        help="Optional path to save JSON output")
    parser.add_argument("--all",      action="store_true",
                        help="Run all scenarios and print comparison table")
    args = parser.parse_args()

    if args.all:
        run_all_scenarios(args.seed)
        return

    if args.scenario not in SCENARIO_CONFIGS:
        print(f"❌ Unknown scenario '{args.scenario}'. "
              f"Choose from: {list(SCENARIO_CONFIGS)}")
        sys.exit(1)

    run_and_display(args.scenario, args.seed, args.output)


if __name__ == "__main__":
    main()

"""
Flood Detection & Multi-Modal Evidence Fusion Engine.

Uses rule-based scoring across three data streams:
  1. Weather / sensor readings
  2. Satellite flood polygons
  3. Social distress reports

Produces a FloodEvent with GeoJSON affected area.
"""
from __future__ import annotations
import uuid
import datetime
import math
from typing import Dict, List, Any, Optional
from ..schemas.models import (
    WeatherReading, SatellitePolygon, DistressReport,
    FloodEvent, Severity,
)


# ── Thresholds ────────────────────────────────────────────────────────────────

RAINFALL_THRESHOLD_MM = 30.0          # mm/hr
RIVER_LEVEL_CRITICAL_M = 5.0         # metres
SATELLITE_CONFIDENCE_MIN = 0.6
DISTRESS_REPORTS_MIN = 5
DISTRESS_SEVERITY_THRESHOLD = 3


class FloodDetector:
    """
    Multi-modal flood detection with explainable evidence fusion.
    """

    def __init__(self, scenario: str = "S3"):
        self.scenario = scenario

    # ── Individual Scorers ────────────────────────────────────────────────────

    def _score_weather(self, readings: List[WeatherReading]) -> Dict[str, Any]:
        if not readings:
            return {"score": 0.0, "evidence": "No weather data available."}
        max_rain = max(r.rainfall_mm_per_hr for r in readings)
        max_level = max(r.river_level_m for r in readings)
        rain_score = min(max_rain / 100.0, 1.0)
        level_score = min(max(max_level - RIVER_LEVEL_CRITICAL_M, 0) / 5.0, 1.0)
        combined = 0.5 * rain_score + 0.5 * level_score
        evidence = (
            f"Max rainfall: {max_rain:.1f} mm/hr, "
            f"Max river level: {max_level:.2f} m. "
            f"Rain score={rain_score:.2f}, Level score={level_score:.2f}."
        )
        return {"score": combined, "evidence": evidence}

    def _score_satellite(self, polygons: List[SatellitePolygon]) -> Dict[str, Any]:
        if not polygons:
            return {"score": 0.0, "evidence": "No satellite data available."}
        avg_conf = sum(p.confidence for p in polygons) / len(polygons)
        score = avg_conf if avg_conf >= SATELLITE_CONFIDENCE_MIN else avg_conf * 0.4
        evidence = (
            f"{len(polygons)} satellite pass(es). "
            f"Avg confidence: {avg_conf:.2f}. "
            f"{'Flood polygon confirmed.' if avg_conf >= SATELLITE_CONFIDENCE_MIN else 'Low satellite confidence.'}"
        )
        return {"score": score, "evidence": evidence}

    def _score_social(self, reports: List[DistressReport]) -> Dict[str, Any]:
        if not reports:
            return {"score": 0.0, "evidence": "No distress reports."}
        verified = [r for r in reports if r.verified]
        high_sev = [r for r in reports if r.severity_estimate >= DISTRESS_SEVERITY_THRESHOLD]
        volume_score = min(len(reports) / 20.0, 1.0)
        verified_score = min(len(verified) / max(len(reports), 1), 1.0)
        severity_score = min(len(high_sev) / max(len(reports), 1), 1.0)
        combined = 0.4 * volume_score + 0.3 * verified_score + 0.3 * severity_score
        evidence = (
            f"{len(reports)} distress reports ({len(verified)} verified). "
            f"{len(high_sev)} high-severity cases. "
            f"Social score={combined:.2f}."
        )
        return {"score": combined, "evidence": evidence}

    # ── Fusion ────────────────────────────────────────────────────────────────

    def _fuse_scores(
        self,
        weather_result: Dict,
        satellite_result: Dict,
        social_result: Dict,
    ) -> float:
        """Weighted evidence fusion."""
        w_weather, w_sat, w_social = 0.35, 0.40, 0.25
        fused = (
            w_weather * weather_result["score"]
            + w_sat    * satellite_result["score"]
            + w_social * social_result["score"]
        )
        return min(fused, 1.0)

    # ── GeoJSON Area Generation ───────────────────────────────────────────────

    def _make_affected_area(
        self,
        reports: List[DistressReport],
        polygons: List[SatellitePolygon],
        confidence: float,
    ) -> Dict[str, Any]:
        """
        Build a GeoJSON FeatureCollection representing the affected area.
        Uses satellite polygons if available, otherwise derives bounding area
        from distress report locations.
        """
        features = []

        # Add satellite polygons
        for p in polygons:
            feat = dict(p.flood_polygon)
            feat["properties"] = {**feat.get("properties", {}), "type": "satellite_flood_zone"}
            features.append(feat)

        # Add distress report points
        for r in reports:
            features.append({
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [r.location["lon"], r.location["lat"]],
                },
                "properties": {
                    "type": "distress_report",
                    "report_id": r.report_id,
                    "severity": r.severity_estimate,
                    "num_people": r.num_people,
                    "verified": r.verified,
                    "message": r.message[:80],
                },
            })

        # Estimated flood extent polygon (derived from bounding box of reports)
        if reports:
            lats = [r.location["lat"] for r in reports]
            lons = [r.location["lon"] for r in reports]
            pad = 0.02 * confidence
            extent = {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [min(lons) - pad, min(lats) - pad],
                        [max(lons) + pad, min(lats) - pad],
                        [max(lons) + pad, max(lats) + pad],
                        [min(lons) - pad, max(lats) + pad],
                        [min(lons) - pad, min(lats) - pad],
                    ]],
                },
                "properties": {"type": "estimated_flood_extent", "confidence": confidence},
            }
            features.append(extent)

        return {"type": "FeatureCollection", "features": features}

    # ── Epicenter ─────────────────────────────────────────────────────────────

    def _compute_epicenter(self, reports: List[DistressReport]) -> Dict[str, float]:
        if not reports:
            return {"lat": 23.8103, "lon": 90.4125}
        lats = [r.location["lat"] for r in reports]
        lons = [r.location["lon"] for r in reports]
        return {"lat": sum(lats) / len(lats), "lon": sum(lons) / len(lons)}

    def _classify_severity(self, confidence: float, risk: float) -> Severity:
        score = 0.6 * confidence + 0.4 * (risk / 10.0)
        if score < 0.2:  return Severity.LOW
        if score < 0.4:  return Severity.MODERATE
        if score < 0.6:  return Severity.HIGH
        if score < 0.8:  return Severity.SEVERE
        return Severity.EXTREME

    # ── Main Detection ────────────────────────────────────────────────────────

    def detect(
        self,
        weather_readings: List[WeatherReading],
        satellite_polygons: List[SatellitePolygon],
        distress_reports: List[DistressReport],
    ) -> FloodEvent:
        w = self._score_weather(weather_readings)
        s = self._score_satellite(satellite_polygons)
        d = self._score_social(distress_reports)

        confidence = self._fuse_scores(w, s, d)
        total_people = sum(r.num_people for r in distress_reports)
        risk_score = confidence * 10.0

        severity = self._classify_severity(confidence, risk_score)
        epicenter = self._compute_epicenter(distress_reports)
        affected_geojson = self._make_affected_area(distress_reports, satellite_polygons, confidence)

        evidence = [w["evidence"], s["evidence"], d["evidence"]]

        return FloodEvent(
            event_id=f"EVT-{self.scenario}-{uuid.uuid4().hex[:8].upper()}",
            scenario=self.scenario,
            detected_at=datetime.datetime.now(),
            epicenter=epicenter,
            severity=severity,
            confidence=round(confidence, 3),
            affected_area_geojson=affected_geojson,
            evidence=evidence,
            risk_score=round(risk_score, 2),
            estimated_affected_people=total_people,
            active=confidence > 0.3,
        )

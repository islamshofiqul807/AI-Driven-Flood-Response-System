"""
Core Pydantic schemas / data contracts for the Disaster Response System.
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from enum import Enum
import datetime


# ── Enums ────────────────────────────────────────────────────────────────────

class Severity(int, Enum):
    LOW       = 1
    MODERATE  = 2
    HIGH      = 3
    SEVERE    = 4
    EXTREME   = 5

class ResourceType(str, Enum):
    RESCUE_BOAT  = "rescue_boat"
    HELICOPTER   = "helicopter"
    AMBULANCE    = "ambulance"
    SHELTER      = "shelter"
    SUPPLY_TRUCK = "supply_truck"

class AgentRole(str, Enum):
    TRIAGE    = "triage"
    CLUSTER   = "cluster"
    RESOURCE  = "resource"
    ROUTING   = "routing"
    MEDICAL   = "medical"
    COMMAND   = "command"
    RESCUE    = "rescue"

class RescueTeamStatus(str, Enum):
    STANDBY   = "standby"
    EN_ROUTE  = "en_route"
    ON_SCENE  = "on_scene"
    RETURNING = "returning"


# ── Weather / Sensor Data ────────────────────────────────────────────────────

class WeatherReading(BaseModel):
    timestamp: datetime.datetime
    location: Dict[str, float]          # {"lat": ..., "lon": ...}
    rainfall_mm_per_hr: float
    river_level_m: float
    wind_speed_kmh: float = 0.0
    temperature_c: float = 25.0

class SatellitePolygon(BaseModel):
    timestamp: datetime.datetime
    flood_polygon: Dict[str, Any]       # GeoJSON Polygon feature
    confidence: float = Field(ge=0, le=1)
    source: str = "satellite"

class DistressReport(BaseModel):
    report_id: str
    timestamp: datetime.datetime
    location: Dict[str, float]
    message: str
    severity_estimate: int = Field(ge=1, le=5)
    verified: bool = False
    num_people: int = 1


# ── Flood Event ───────────────────────────────────────────────────────────────

class FloodEvent(BaseModel):
    event_id: str
    scenario: str
    detected_at: datetime.datetime
    epicenter: Dict[str, float]         # {"lat": ..., "lon": ...}
    severity: Severity
    confidence: float = Field(ge=0, le=1)
    affected_area_geojson: Dict[str, Any]
    evidence: List[str] = []
    risk_score: float = Field(ge=0, le=10)
    estimated_affected_people: int = 0
    active: bool = True


# ── Planning / Response ───────────────────────────────────────────────────────

class DistressCase(BaseModel):
    case_id: str
    location: Dict[str, float]
    urgency_score: float = Field(ge=0, le=10)
    num_people: int = 1
    medical_need: bool = False
    cluster_id: Optional[int] = None
    assigned_resource: Optional[str] = None
    eta_minutes: Optional[float] = None

class ResourceUnit(BaseModel):
    unit_id: str
    resource_type: ResourceType
    location: Dict[str, float]
    capacity: int
    available: bool = True
    assigned_cases: List[str] = []

class ShelterSite(BaseModel):
    shelter_id: str
    name: str
    location: Dict[str, float]
    capacity: int
    current_occupancy: int = 0
    amenities: List[str] = []

class RouteSegment(BaseModel):
    from_location: Dict[str, float]
    to_location: Dict[str, float]
    distance_km: float
    hazard_level: float = Field(ge=0, le=1)
    estimated_time_min: float

class DispatchPlan(BaseModel):
    plan_id: str
    flood_event_id: str
    created_at: datetime.datetime
    cases: List[DistressCase]
    resources: List[ResourceUnit]
    shelters: List[ShelterSite]
    routes: List[RouteSegment]
    total_cases: int
    high_urgency_cases: int
    notes: str = ""


# ── Agent Messages ────────────────────────────────────────────────────────────

class AgentDecision(BaseModel):
    agent: AgentRole
    timestamp: datetime.datetime
    input_summary: str
    output_summary: str
    reasoning: str
    data: Dict[str, Any] = {}

class SITREP(BaseModel):
    sitrep_id: str
    generated_at: datetime.datetime
    flood_event: FloodEvent
    dispatch_plan: DispatchPlan
    agent_decisions: List[AgentDecision]
    narrative: str
    recommendations: List[str]
    status: str = "ACTIVE"
    rescue_teams: List[Dict[str, Any]] = []
    rescue_assignments: List[Dict[str, Any]] = []


# ── Rescue Teams ─────────────────────────────────────────────────────────────

class RescueTeam(BaseModel):
    team_id: str
    name: str
    team_type: str                        # "boat", "helicopter", "medical", "ground"
    location: Dict[str, float]
    members: int
    status: RescueTeamStatus = RescueTeamStatus.STANDBY
    assigned_case_id: Optional[str] = None
    eta_minutes: Optional[float] = None

class RescueAssignment(BaseModel):
    assignment_id: str
    team: RescueTeam
    case_id: str
    case_location: Dict[str, float]
    urgency_score: float
    dispatched_at: datetime.datetime
    status: RescueTeamStatus
    notes: str = ""


# ── Evaluation ────────────────────────────────────────────────────────────────

class EvaluationMetrics(BaseModel):
    scenario: str
    detection_precision: float
    detection_recall: float
    urgent_case_coverage_pct: float
    avg_response_time_min: float
    resource_utilization_rate: float
    route_safety_score: float
    fairness_distribution_score: float
    overall_score: float
    notes: str = ""

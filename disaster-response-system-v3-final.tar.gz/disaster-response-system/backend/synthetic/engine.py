"""
Synthetic Data Engine
Generates reproducible multi-modal disaster data streams.
"""
from __future__ import annotations
import random
import uuid
import datetime
from typing import Dict, List, Tuple
from ..schemas.models import WeatherReading, SatellitePolygon, DistressReport

# Bangladesh / Dhaka area base coordinates (realistic flood-prone region)
BASE_LAT = 23.8103
BASE_LON = 90.4125

SCENARIO_CONFIGS: Dict[str, Dict] = {
    "S1": {
        "name": "No Flood (False Positive Test)",
        "rainfall_range": (0, 5),
        "river_level_range": (1.0, 2.0),
        "satellite_confidence": 0.1,
        "num_distress": 2,
        "distress_severity_range": (1, 2),
        "num_people_range": (1, 3),
    },
    "S2": {
        "name": "Flash Flood",
        "rainfall_range": (80, 150),
        "river_level_range": (6.5, 9.0),
        "satellite_confidence": 0.88,
        "num_distress": 18,
        "distress_severity_range": (3, 5),
        "num_people_range": (2, 10),
    },
    "S3": {
        "name": "River Flood (Slow Expansion)",
        "rainfall_range": (30, 70),
        "river_level_range": (4.0, 7.5),
        "satellite_confidence": 0.75,
        "num_distress": 12,
        "distress_severity_range": (2, 4),
        "num_people_range": (1, 8),
    },
    "S4": {
        "name": "Social Misinformation",
        "rainfall_range": (10, 25),
        "river_level_range": (2.0, 3.5),
        "satellite_confidence": 0.2,
        "num_distress": 20,
        "distress_severity_range": (1, 3),
        "num_people_range": (1, 4),
    },
    "S5": {
        "name": "Medical-Heavy Emergency",
        "rainfall_range": (60, 100),
        "river_level_range": (5.5, 8.0),
        "satellite_confidence": 0.82,
        "num_distress": 15,
        "distress_severity_range": (3, 5),
        "num_people_range": (1, 6),
        "medical_heavy": True,
    },
    "S6": {
        "name": "Missing Satellite Evidence",
        "rainfall_range": (55, 90),
        "river_level_range": (5.0, 7.0),
        "satellite_confidence": 0.0,   # No satellite
        "num_distress": 10,
        "distress_severity_range": (2, 5),
        "num_people_range": (1, 7),
    },
}

DISTRESS_MESSAGES = [
    "Help! Water rising fast, trapped on rooftop with family",
    "Need immediate evacuation – elderly and children present",
    "Flood water entered house, need rescue boat",
    "Medical emergency – diabetic patient needs assistance",
    "Road completely submerged, car stuck",
    "Roof collapsed, three people injured",
    "No food or clean water for two days",
    "Infant and pregnant woman need urgent help",
    "Bridge washed out, community cut off",
    "Livestock and crops destroyed, people displaced",
    "Heard explosion near power station, fire and flood combined",
    "Multiple families stranded, estimate 30+ people",
]


class SyntheticDataEngine:
    """Generates reproducible synthetic disaster data streams."""

    def __init__(self, scenario: str = "S3", seed: int = 42):
        if scenario not in SCENARIO_CONFIGS:
            raise ValueError(f"Unknown scenario '{scenario}'. Choose from {list(SCENARIO_CONFIGS)}")
        self.scenario = scenario
        self.config = SCENARIO_CONFIGS[scenario]
        self.seed = seed
        self.rng = random.Random(seed)
        self.base_time = datetime.datetime(2024, 7, 15, 6, 0, 0)

    def _jitter(self, lat: float, lon: float, scale: float = 0.05) -> Tuple[float, float]:
        return (
            lat + self.rng.uniform(-scale, scale),
            lon + self.rng.uniform(-scale, scale),
        )

    # ── Weather Stream ────────────────────────────────────────────────────────

    def generate_weather_stream(self, num_readings: int = 6) -> List[WeatherReading]:
        readings = []
        r_lo, r_hi = self.config["rainfall_range"]
        lv_lo, lv_hi = self.config["river_level_range"]
        for i in range(num_readings):
            ts = self.base_time + datetime.timedelta(hours=i)
            lat, lon = self._jitter(BASE_LAT, BASE_LON, 0.02)
            readings.append(WeatherReading(
                timestamp=ts,
                location={"lat": lat, "lon": lon},
                rainfall_mm_per_hr=self.rng.uniform(r_lo, r_hi),
                river_level_m=self.rng.uniform(lv_lo, lv_hi),
                wind_speed_kmh=self.rng.uniform(10, 60),
                temperature_c=self.rng.uniform(25, 35),
            ))
        return readings

    # ── Satellite Polygons ────────────────────────────────────────────────────

    def generate_satellite_polygons(self, num_passes: int = 2) -> List[SatellitePolygon]:
        conf = self.config["satellite_confidence"]
        if conf == 0.0:
            return []
        polygons = []
        for i in range(num_passes):
            lat, lon = self._jitter(BASE_LAT, BASE_LON, 0.03)
            spread = 0.04 + self.rng.uniform(0, 0.04)
            coords = [
                [lon - spread, lat - spread],
                [lon + spread, lat - spread],
                [lon + spread, lat + spread],
                [lon - spread, lat + spread],
                [lon - spread, lat - spread],
            ]
            geojson_polygon = {
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [coords]},
                "properties": {"source": "satellite", "pass": i},
            }
            polygons.append(SatellitePolygon(
                timestamp=self.base_time + datetime.timedelta(hours=i * 2),
                flood_polygon=geojson_polygon,
                confidence=self.rng.uniform(conf - 0.05, min(conf + 0.05, 1.0)),
            ))
        return polygons

    # ── Distress Reports ──────────────────────────────────────────────────────

    def generate_distress_reports(self) -> List[DistressReport]:
        n = self.config["num_distress"]
        sev_lo, sev_hi = self.config["distress_severity_range"]
        p_lo, p_hi = self.config["num_people_range"]
        medical_heavy = self.config.get("medical_heavy", False)
        reports = []
        for i in range(n):
            lat, lon = self._jitter(BASE_LAT, BASE_LON, 0.08)
            sev = self.rng.randint(sev_lo, sev_hi)
            # In S4 (misinformation), bias toward low severity but high message drama
            if self.scenario == "S4":
                sev = min(sev, 2)
            reports.append(DistressReport(
                report_id=f"RPT-{self.scenario}-{i+1:03d}",
                timestamp=self.base_time + datetime.timedelta(minutes=self.rng.randint(0, 120)),
                location={"lat": lat, "lon": lon},
                message=self.rng.choice(DISTRESS_MESSAGES),
                severity_estimate=sev,
                verified=self.rng.random() > 0.4,
                num_people=self.rng.randint(p_lo, p_hi),
            ))
        return reports

    # ── Ground Truth (for evaluation) ─────────────────────────────────────────

    def generate_ground_truth(self) -> Dict:
        conf = self.config["satellite_confidence"]
        is_real_flood = conf > 0.5 or self.config["river_level_range"][1] > 5.0
        return {
            "scenario": self.scenario,
            "is_real_flood": is_real_flood,
            "true_affected_radius_km": 5.0 if is_real_flood else 0.5,
            "true_num_affected": self.config["num_distress"] * self.config["num_people_range"][1] if is_real_flood else 0,
        }

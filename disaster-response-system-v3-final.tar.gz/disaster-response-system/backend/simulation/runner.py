"""
Simulation Runner

End-to-end orchestration:
  SyntheticData → Detection → Planning → Agents (incl. Rescue) → Evaluation
"""
from __future__ import annotations
import json
from typing import Dict, Any, List, Tuple
import datetime

from ..synthetic.engine import SyntheticDataEngine, SCENARIO_CONFIGS
from ..detection.flood_detector import FloodDetector
from ..planning.engine import PlanningEngine
from ..agents.orchestrator import MultiAgentOrchestrator
from ..evaluation.evaluator import EvaluationEngine
from ..schemas.models import FloodEvent, DispatchPlan, SITREP, EvaluationMetrics


class SimulationResult:
    """Container for a complete simulation run."""

    def __init__(
        self,
        scenario: str,
        flood_event: FloodEvent,
        dispatch_plan: DispatchPlan,
        sitrep: SITREP,
        metrics: EvaluationMetrics,
        timeline: List[Tuple[str, datetime.datetime]],
    ):
        self.scenario      = scenario
        self.flood_event   = flood_event
        self.dispatch_plan = dispatch_plan
        self.sitrep        = sitrep
        self.metrics       = metrics
        self.timeline      = timeline

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario":      self.scenario,
            "flood_event":   self.flood_event.model_dump(mode="json"),
            "dispatch_plan": self.dispatch_plan.model_dump(mode="json"),
            "sitrep":        self.sitrep.model_dump(mode="json"),
            "metrics":       self.metrics.model_dump(mode="json"),
            "timeline":      [(label, str(ts)) for label, ts in self.timeline],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def rescue_summary(self) -> Dict[str, Any]:
        """Convenience method for rescue team statistics."""
        asgns    = self.sitrep.rescue_assignments
        teams    = self.sitrep.rescue_teams
        return {
            "total_teams":   len(teams),
            "dispatched":    len(asgns),
            "on_scene":      sum(1 for a in asgns if a["status"] == "on_scene"),
            "en_route":      sum(1 for a in asgns if a["status"] == "en_route"),
            "standby":       sum(1 for t in teams if t["status"] == "standby"),
            "coverage_pct":  round(len(asgns) / max(self.dispatch_plan.total_cases, 1) * 100, 1),
        }


class SimulationRunner:
    """Runs the full disaster response simulation pipeline."""

    def run(self, scenario: str = "S3", seed: int = 42) -> SimulationResult:
        timeline: List[Tuple[str, datetime.datetime]] = []

        def mark(label: str):
            timeline.append((label, datetime.datetime.now()))

        # 1. Synthetic data
        mark("Synthetic data generated")
        engine       = SyntheticDataEngine(scenario=scenario, seed=seed)
        weather      = engine.generate_weather_stream()
        satellite    = engine.generate_satellite_polygons()
        reports      = engine.generate_distress_reports()
        ground_truth = engine.generate_ground_truth()

        # 2. Flood detection
        mark("Flood detection complete")
        detector    = FloodDetector(scenario=scenario)
        flood_event = detector.detect(weather, satellite, reports)

        # 3. Planning
        mark("Dispatch plan created")
        planner       = PlanningEngine(seed=seed)
        dispatch_plan = planner.create_plan(flood_event, reports)

        # 4. Multi-agent orchestration (includes rescue agent)
        mark("Agent orchestration complete")
        orchestrator = MultiAgentOrchestrator()
        sitrep       = orchestrator.run(flood_event, dispatch_plan)

        # 5. Rescue agent summary logged separately
        rescue_info = sitrep.rescue_assignments
        mark(
            f"Rescue agent: {len(rescue_info)} team(s) dispatched"
            if rescue_info else "Rescue agent: standby (flood not active)"
        )

        # 6. Evaluation
        mark("Evaluation complete")
        evaluator = EvaluationEngine()
        metrics   = evaluator.evaluate(flood_event, dispatch_plan, ground_truth)

        return SimulationResult(
            scenario=scenario,
            flood_event=flood_event,
            dispatch_plan=dispatch_plan,
            sitrep=sitrep,
            metrics=metrics,
            timeline=timeline,
        )

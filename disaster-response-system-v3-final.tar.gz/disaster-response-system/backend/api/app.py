"""
FastAPI REST API for the Disaster Response System
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Any, Dict
from backend.simulation.runner import SimulationRunner
from backend.synthetic.engine import SCENARIO_CONFIGS

app = FastAPI(
    title="AI Disaster Response System API",
    description="End-to-end flood detection and response planning API.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_runner = SimulationRunner()
_cache: Dict[str, Any] = {}


@app.get("/")
def root():
    return {"message": "AI Disaster Response System API", "version": "1.0.0"}


@app.get("/scenarios")
def list_scenarios():
    """List all available scenarios."""
    return {
        "scenarios": [
            {"id": k, "name": v["name"]}
            for k, v in SCENARIO_CONFIGS.items()
        ]
    }


@app.get("/run/{scenario}")
def run_simulation(
    scenario: str,
    seed: int = Query(default=42, description="Random seed for reproducibility"),
):
    """Run the full simulation pipeline for a given scenario."""
    cache_key = f"{scenario}_{seed}"
    if cache_key in _cache:
        return _cache[cache_key]

    if scenario not in SCENARIO_CONFIGS:
        raise HTTPException(status_code=404, detail=f"Unknown scenario '{scenario}'")

    result = _runner.run(scenario=scenario, seed=seed)
    data = result.to_dict()
    _cache[cache_key] = data
    return data


@app.get("/run/{scenario}/flood-event")
def get_flood_event(scenario: str, seed: int = 42):
    """Get only the flood event for a scenario."""
    data = run_simulation(scenario, seed)
    return data["flood_event"]


@app.get("/run/{scenario}/geojson")
def get_geojson(scenario: str, seed: int = 42):
    """Get the affected area GeoJSON."""
    data = run_simulation(scenario, seed)
    return data["flood_event"]["affected_area_geojson"]


@app.get("/run/{scenario}/metrics")
def get_metrics(scenario: str, seed: int = 42):
    """Get evaluation metrics."""
    data = run_simulation(scenario, seed)
    return data["metrics"]


@app.get("/run/{scenario}/sitrep")
def get_sitrep(scenario: str, seed: int = 42):
    """Get the SITREP."""
    data = run_simulation(scenario, seed)
    return {
        "narrative": data["sitrep"]["narrative"],
        "recommendations": data["sitrep"]["recommendations"],
        "status": data["sitrep"]["status"],
    }


@app.get("/health")
def health():
    return {"status": "ok"}

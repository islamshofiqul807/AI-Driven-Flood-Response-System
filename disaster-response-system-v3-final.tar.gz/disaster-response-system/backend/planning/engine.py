"""
Deterministic Planning Engine

Responsibilities:
  - Urgency scoring for each distress case
  - Geographic clustering (k-means style)
  - Resource allocation
  - Shelter assignment
  - Safe route planning with NetworkX
"""
from __future__ import annotations
import uuid
import math
import datetime
import random
from typing import Dict, List, Optional, Tuple
import networkx as nx
from ..schemas.models import (
    DistressReport, FloodEvent, DistressCase, ResourceUnit,
    ShelterSite, RouteSegment, DispatchPlan, ResourceType,
)

# Pre-defined resource depot (Dhaka)
RESOURCE_DEPOT = {"lat": 23.8103, "lon": 90.4125}

# Pre-defined shelters
SHELTER_TEMPLATES = [
    {"name": "Mirpur Shelter A",    "lat": 23.835, "lon": 90.366, "capacity": 200},
    {"name": "Mohakhali Relief Hub","lat": 23.779, "lon": 90.404, "capacity": 150},
    {"name": "Uttara Community Hall","lat": 23.874, "lon": 90.399, "capacity": 300},
    {"name": "Demra Emergency Camp","lat": 23.730, "lon": 90.449, "capacity": 250},
]

RESOURCE_POOL = [
    {"type": ResourceType.RESCUE_BOAT,  "count": 4, "capacity": 8},
    {"type": ResourceType.HELICOPTER,   "count": 2, "capacity": 15},
    {"type": ResourceType.AMBULANCE,    "count": 3, "capacity": 4},
    {"type": ResourceType.SUPPLY_TRUCK, "count": 3, "capacity": 50},
]


def haversine_km(loc1: Dict, loc2: Dict) -> float:
    """Great-circle distance in km."""
    R = 6371
    lat1, lon1 = math.radians(loc1["lat"]), math.radians(loc1["lon"])
    lat2, lon2 = math.radians(loc2["lat"]), math.radians(loc2["lon"])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return R * 2 * math.asin(math.sqrt(a))


class PlanningEngine:
    """End-to-end deterministic planning engine."""

    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed)

    # ── Urgency Scoring ────────────────────────────────────────────────────────

    def _urgency_score(self, report: DistressReport) -> float:
        """
        Score 0-10.
        Components:
          - severity_estimate (1-5) → 40%
          - num_people (normalised to 1-10) → 30%
          - verified bonus → 15%
          - medical keyword → 15%
        """
        sev_score   = (report.severity_estimate / 5) * 4.0
        people_score = min(report.num_people / 10, 1.0) * 3.0
        verified_bonus = 1.5 if report.verified else 0.0
        medical_kw = ["medical", "diabetic", "infant", "pregnant", "injured"]
        medical_bonus = 1.5 if any(kw in report.message.lower() for kw in medical_kw) else 0.0
        return round(min(sev_score + people_score + verified_bonus + medical_bonus, 10.0), 2)

    def _build_cases(self, reports: List[DistressReport]) -> List[DistressCase]:
        cases = []
        medical_kw = ["medical", "diabetic", "infant", "pregnant", "injured"]
        for r in reports:
            medical = any(kw in r.message.lower() for kw in medical_kw)
            cases.append(DistressCase(
                case_id=r.report_id,
                location=r.location,
                urgency_score=self._urgency_score(r),
                num_people=r.num_people,
                medical_need=medical,
            ))
        return sorted(cases, key=lambda c: c.urgency_score, reverse=True)

    # ── Geographic Clustering ──────────────────────────────────────────────────

    def _cluster_cases(self, cases: List[DistressCase], k: int = 3) -> List[DistressCase]:
        """Simple k-means-style geographic clustering."""
        if not cases:
            return cases
        k = min(k, len(cases))
        # Seed centroids from highest urgency cases
        centroids = [cases[i].location for i in range(k)]

        for _ in range(10):  # iterations
            # Assign
            for c in cases:
                dists = [haversine_km(c.location, cen) for cen in centroids]
                c.cluster_id = dists.index(min(dists))
            # Update centroids
            for cid in range(k):
                cluster = [c for c in cases if c.cluster_id == cid]
                if cluster:
                    centroids[cid] = {
                        "lat": sum(c.location["lat"] for c in cluster) / len(cluster),
                        "lon": sum(c.location["lon"] for c in cluster) / len(cluster),
                    }
        return cases

    # ── Resource Generation ────────────────────────────────────────────────────

    def _generate_resources(self) -> List[ResourceUnit]:
        units = []
        for pool in RESOURCE_POOL:
            for i in range(pool["count"]):
                jitter_lat = RESOURCE_DEPOT["lat"] + self.rng.uniform(-0.01, 0.01)
                jitter_lon = RESOURCE_DEPOT["lon"] + self.rng.uniform(-0.01, 0.01)
                units.append(ResourceUnit(
                    unit_id=f"{pool['type'].value.upper()}-{i+1:02d}",
                    resource_type=pool["type"],
                    location={"lat": jitter_lat, "lon": jitter_lon},
                    capacity=pool["capacity"],
                ))
        return units

    # ── Resource Allocation ────────────────────────────────────────────────────

    def _allocate_resources(
        self,
        cases: List[DistressCase],
        resources: List[ResourceUnit],
    ) -> Tuple[List[DistressCase], List[ResourceUnit]]:
        """Greedy allocation: assign nearest available resource to each case."""
        for case in cases:
            if case.medical_need:
                # Prefer ambulance or helicopter
                pref_types = [ResourceType.AMBULANCE, ResourceType.HELICOPTER, ResourceType.RESCUE_BOAT]
            elif case.num_people > 6:
                pref_types = [ResourceType.HELICOPTER, ResourceType.RESCUE_BOAT]
            else:
                pref_types = [ResourceType.RESCUE_BOAT, ResourceType.HELICOPTER]

            assigned = None
            for rtype in pref_types:
                candidates = [r for r in resources if r.resource_type == rtype and r.available]
                if candidates:
                    # Nearest
                    nearest = min(candidates, key=lambda r: haversine_km(r.location, case.location))
                    dist = haversine_km(nearest.location, case.location)
                    nearest.assigned_cases.append(case.case_id)
                    case.assigned_resource = nearest.unit_id
                    case.eta_minutes = round(dist / 30 * 60, 1)  # assume 30 km/h speed
                    if len(nearest.assigned_cases) >= nearest.capacity:
                        nearest.available = False
                    assigned = nearest
                    break
        return cases, resources

    # ── Shelter Assignment ─────────────────────────────────────────────────────

    def _build_shelters(self) -> List[ShelterSite]:
        return [
            ShelterSite(
                shelter_id=f"SHLT-{i+1:02d}",
                name=s["name"],
                location={"lat": s["lat"], "lon": s["lon"]},
                capacity=s["capacity"],
                amenities=["water", "food", "medical_station"] if i % 2 == 0 else ["water", "food"],
            )
            for i, s in enumerate(SHELTER_TEMPLATES)
        ]

    # ── Route Planning ─────────────────────────────────────────────────────────

    def _plan_routes(
        self,
        cases: List[DistressCase],
        resources: List[ResourceUnit],
    ) -> List[RouteSegment]:
        """
        Build a simple graph with hazard weights and extract routes.
        Nodes: resource locations + case locations.
        Edge weight includes distance + hazard penalty.
        """
        G = nx.Graph()
        nodes: Dict[str, Dict] = {}

        # Add resource depot nodes
        for r in resources:
            nid = r.unit_id
            G.add_node(nid, pos=(r.location["lat"], r.location["lon"]))
            nodes[nid] = r.location

        # Add case nodes
        for c in cases:
            nid = c.case_id
            G.add_node(nid, pos=(c.location["lat"], c.location["lon"]))
            nodes[nid] = c.location

        # Add edges between all nodes (complete graph, weighted by distance)
        node_ids = list(nodes.keys())
        for i in range(len(node_ids)):
            for j in range(i + 1, len(node_ids)):
                a, b = node_ids[i], node_ids[j]
                dist = haversine_km(nodes[a], nodes[b])
                hazard = self.rng.uniform(0, 0.6)  # Simulated hazard level
                weight = dist + hazard * 2
                G.add_edge(a, b, distance=dist, hazard=hazard, weight=weight)

        routes = []
        for case in cases[:8]:  # Limit to first 8 for tractability
            if case.assigned_resource and case.assigned_resource in nodes:
                src = case.assigned_resource
                dst = case.case_id
                try:
                    path = nx.shortest_path(G, src, dst, weight="weight")
                    for k in range(len(path) - 1):
                        a, b = path[k], path[k + 1]
                        edge = G[a][b]
                        routes.append(RouteSegment(
                            from_location=nodes[a],
                            to_location=nodes[b],
                            distance_km=round(edge["distance"], 3),
                            hazard_level=round(edge["hazard"], 3),
                            estimated_time_min=round(edge["distance"] / 30 * 60, 1),
                        ))
                except nx.NetworkXNoPath:
                    pass
        return routes

    # ── Master Plan ───────────────────────────────────────────────────────────

    def create_plan(
        self,
        flood_event: FloodEvent,
        distress_reports: List[DistressReport],
        num_clusters: int = 3,
    ) -> DispatchPlan:
        cases = self._build_cases(distress_reports)
        cases = self._cluster_cases(cases, k=num_clusters)
        resources = self._generate_resources()
        shelters = self._build_shelters()
        cases, resources = self._allocate_resources(cases, resources)
        routes = self._plan_routes(cases, resources)

        high_urgency = [c for c in cases if c.urgency_score >= 6.0]

        return DispatchPlan(
            plan_id=f"PLAN-{uuid.uuid4().hex[:8].upper()}",
            flood_event_id=flood_event.event_id,
            created_at=datetime.datetime.now(),
            cases=cases,
            resources=resources,
            shelters=shelters,
            routes=routes,
            total_cases=len(cases),
            high_urgency_cases=len(high_urgency),
            notes=f"Plan generated for scenario {flood_event.scenario} with "
                  f"{len(resources)} resources and {len(shelters)} shelters.",
        )

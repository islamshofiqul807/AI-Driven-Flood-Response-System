"""
Multi-Agent Orchestrator

Agents:
  1. Triage Agent      – prioritises distress cases
  2. Cluster Agent     – groups cases geographically
  3. Resource Agent    – allocates units
  4. Routing Agent     – plans safe routes
  5. Medical Agent     – flags medical priorities
  6. Command Agent     – synthesises decisions + SITREP

Each agent produces an AgentDecision with transparent reasoning.
If OPENAI_API_KEY is not configured, the system falls back to
deterministic reasoning without LLM calls.
"""
from __future__ import annotations
import os
import uuid
import datetime
import json
from typing import List, Optional, Dict, Any

from ..schemas.models import (
    FloodEvent, DispatchPlan, AgentDecision, AgentRole, SITREP,
)
from .rescue_agent import RescueAgent

# Optional OpenAI import
try:
    from openai import OpenAI
    _OPENAI_AVAILABLE = True
except ImportError:
    _OPENAI_AVAILABLE = False


def _get_openai_client() -> Optional[Any]:
    api_key = os.getenv("OPENAI_API_KEY", "")
    if api_key and _OPENAI_AVAILABLE:
        return OpenAI(api_key=api_key)
    return None


def _llm_reason(client, system: str, user: str, max_tokens: int = 400) -> str:
    """Call OpenAI with fallback."""
    if client is None:
        return "[LLM not configured – deterministic fallback active]"
    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            max_tokens=max_tokens,
            temperature=0.2,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"[LLM error: {e}]"


class MultiAgentOrchestrator:
    """Orchestrates all agents and produces SITREP."""

    def __init__(self):
        self.client = _get_openai_client()

    def _ts(self) -> datetime.datetime:
        return datetime.datetime.now()

    # ── Agent 1: Triage ───────────────────────────────────────────────────────

    def _triage_agent(self, plan: DispatchPlan) -> AgentDecision:
        high = [c for c in plan.cases if c.urgency_score >= 7.0]
        med  = [c for c in plan.cases if 4.0 <= c.urgency_score < 7.0]
        low  = [c for c in plan.cases if c.urgency_score < 4.0]

        reasoning = _llm_reason(
            self.client,
            "You are a disaster response triage coordinator. Be concise and clinical.",
            f"Triage summary: {len(high)} critical, {len(med)} moderate, {len(low)} low-urgency cases. "
            f"Total people affected: {sum(c.num_people for c in plan.cases)}. "
            "What are the top 3 triage priorities?",
        ) if self.client else (
            f"Priority 1 – {len(high)} critical cases requiring immediate dispatch. "
            f"Priority 2 – {len(med)} moderate cases to queue after critical. "
            f"Priority 3 – {len(low)} low-urgency cases for shelter-based care."
        )

        return AgentDecision(
            agent=AgentRole.TRIAGE,
            timestamp=self._ts(),
            input_summary=f"{len(plan.cases)} distress cases received.",
            output_summary=f"Critical: {len(high)}, Moderate: {len(med)}, Low: {len(low)}",
            reasoning=reasoning,
            data={
                "critical_count": len(high),
                "moderate_count": len(med),
                "low_count": len(low),
                "critical_case_ids": [c.case_id for c in high[:5]],
            },
        )

    # ── Agent 2: Cluster ──────────────────────────────────────────────────────

    def _cluster_agent(self, plan: DispatchPlan) -> AgentDecision:
        cluster_counts: Dict[int, int] = {}
        for c in plan.cases:
            cid = c.cluster_id or 0
            cluster_counts[cid] = cluster_counts.get(cid, 0) + 1

        reasoning = (
            f"Geographic analysis identifies {len(cluster_counts)} clusters. "
            f"Cluster distribution: {cluster_counts}. "
            "Dispatch resources to highest-density clusters first."
        )

        return AgentDecision(
            agent=AgentRole.CLUSTER,
            timestamp=self._ts(),
            input_summary=f"{len(plan.cases)} cases to cluster.",
            output_summary=f"{len(cluster_counts)} geographic clusters identified.",
            reasoning=reasoning,
            data={"cluster_distribution": cluster_counts},
        )

    # ── Agent 3: Resource ─────────────────────────────────────────────────────

    def _resource_agent(self, plan: DispatchPlan) -> AgentDecision:
        available = [r for r in plan.resources if r.available]
        assigned  = [r for r in plan.resources if not r.available or r.assigned_cases]
        utilization = len(assigned) / max(len(plan.resources), 1)

        reasoning = (
            f"{len(plan.resources)} resource units available. "
            f"{len(assigned)} assigned ({utilization:.0%} utilization). "
            f"Boats: {sum(1 for r in plan.resources if r.resource_type.value == 'rescue_boat')}, "
            f"Helicopters: {sum(1 for r in plan.resources if r.resource_type.value == 'helicopter')}, "
            f"Ambulances: {sum(1 for r in plan.resources if r.resource_type.value == 'ambulance')}. "
            "Resources allocated by proximity and case urgency."
        )

        return AgentDecision(
            agent=AgentRole.RESOURCE,
            timestamp=self._ts(),
            input_summary=f"{len(plan.resources)} resource units.",
            output_summary=f"{len(assigned)} assigned, {len(available)} still available.",
            reasoning=reasoning,
            data={"utilization": round(utilization, 3)},
        )

    # ── Agent 4: Routing ──────────────────────────────────────────────────────

    def _routing_agent(self, plan: DispatchPlan) -> AgentDecision:
        risky  = [r for r in plan.routes if r.hazard_level > 0.5]
        safe   = [r for r in plan.routes if r.hazard_level <= 0.5]
        avg_hazard = (
            sum(r.hazard_level for r in plan.routes) / len(plan.routes)
            if plan.routes else 0.0
        )

        reasoning = (
            f"{len(plan.routes)} route segments planned. "
            f"{len(risky)} high-hazard segments identified and flagged. "
            f"Average route hazard: {avg_hazard:.2f}. "
            "High-hazard segments recommend boat or helicopter deployment."
        )

        return AgentDecision(
            agent=AgentRole.ROUTING,
            timestamp=self._ts(),
            input_summary=f"{len(plan.routes)} route segments.",
            output_summary=f"Safety score: {1 - avg_hazard:.2f}",
            reasoning=reasoning,
            data={
                "risky_segments": len(risky),
                "safe_segments": len(safe),
                "avg_hazard": round(avg_hazard, 3),
            },
        )

    # ── Agent 5: Medical ──────────────────────────────────────────────────────

    def _medical_agent(self, plan: DispatchPlan) -> AgentDecision:
        medical_cases = [c for c in plan.cases if c.medical_need]
        total_medical_people = sum(c.num_people for c in medical_cases)

        reasoning = (
            f"{len(medical_cases)} cases with medical need identified "
            f"(~{total_medical_people} individuals). "
            "Ambulances prioritised for these cases. "
            "Recommend establishing field medical post at nearest shelter."
        )

        return AgentDecision(
            agent=AgentRole.MEDICAL,
            timestamp=self._ts(),
            input_summary=f"{len(plan.cases)} cases scanned for medical urgency.",
            output_summary=f"{len(medical_cases)} medical-priority cases.",
            reasoning=reasoning,
            data={
                "medical_case_count": len(medical_cases),
                "total_medical_people": total_medical_people,
            },
        )

    # ── Agent 6: Command (SITREP) ─────────────────────────────────────────────

    def _command_agent(
        self,
        flood_event: FloodEvent,
        plan: DispatchPlan,
        decisions: List[AgentDecision],
    ) -> tuple[AgentDecision, str, List[str]]:
        decision_summaries = "\n".join(
            f"  [{d.agent.value.upper()}] {d.output_summary}" for d in decisions
        )

        narrative_prompt = (
            f"Flood event: {flood_event.scenario} | Severity: {flood_event.severity.name} | "
            f"Confidence: {flood_event.confidence:.0%} | "
            f"Estimated affected: {flood_event.estimated_affected_people} people.\n"
            f"Agent decisions:\n{decision_summaries}\n"
            "Write a concise 3-sentence operational SITREP narrative."
        )

        narrative = _llm_reason(
            self.client,
            "You are a disaster response command officer writing operational situation reports.",
            narrative_prompt,
            max_tokens=250,
        ) if self.client else (
            f"A {flood_event.severity.name} flood event (confidence {flood_event.confidence:.0%}) "
            f"has been detected in scenario {flood_event.scenario}. "
            f"Response plan activated: {plan.total_cases} distress cases processed, "
            f"{plan.high_urgency_cases} critical. "
            f"All available resources have been dispatched according to urgency and proximity."
        )

        recommendations = [
            f"Evacuate {plan.high_urgency_cases} critical-priority locations immediately.",
            f"Activate {len(plan.shelters)} designated shelter sites.",
            "Deploy field medical teams to clusters with medical cases.",
            "Monitor satellite feeds every 2 hours for flood extent updates.",
            "Issue public communications via radio and SMS broadcast.",
        ]

        cmd_decision = AgentDecision(
            agent=AgentRole.COMMAND,
            timestamp=self._ts(),
            input_summary="All agent decisions received.",
            output_summary=f"SITREP generated. {len(recommendations)} recommendations issued.",
            reasoning="Command synthesised all agent outputs into operational SITREP.",
            data={"narrative": narrative[:200]},
        )

        return cmd_decision, narrative, recommendations

    # ── Orchestrate ───────────────────────────────────────────────────────────

    def run(self, flood_event: FloodEvent, plan: DispatchPlan) -> SITREP:
        decisions: List[AgentDecision] = []

        decisions.append(self._triage_agent(plan))
        decisions.append(self._cluster_agent(plan))
        decisions.append(self._resource_agent(plan))
        decisions.append(self._routing_agent(plan))
        decisions.append(self._medical_agent(plan))

        # ── Rescue Agent ──────────────────────────────────────────────────────
        rescue_agent = RescueAgent()
        rescue_teams, rescue_assignments, rescue_decision = rescue_agent.assign(
            flood_event, plan
        )
        decisions.append(rescue_decision)

        cmd_decision, narrative, recs = self._command_agent(flood_event, plan, decisions)
        decisions.append(cmd_decision)

        return SITREP(
            sitrep_id=f"SITREP-{uuid.uuid4().hex[:8].upper()}",
            generated_at=datetime.datetime.now(),
            flood_event=flood_event,
            dispatch_plan=plan,
            agent_decisions=decisions,
            narrative=narrative,
            recommendations=recs,
            status="ACTIVE" if flood_event.active else "RESOLVED",
            rescue_teams=[t.model_dump() for t in rescue_teams],
            rescue_assignments=[a.model_dump() for a in rescue_assignments],
        )

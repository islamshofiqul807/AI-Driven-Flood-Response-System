"""
Tests for Agent 4 — RouteComputer
OSRM is mocked via httpx; no real network calls.
Run with: pytest tests/test_route_computer.py -v
"""
import json
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
import httpx

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../../"))

from src.agents.agent_4_dispatch.models import GeoPoint, TransportMode
from src.agents.agent_4_dispatch.route_computer import RouteComputer, BOAT_SPEEDS


# ---------------------------------------------------------------------------
# OSRM mock helpers
# ---------------------------------------------------------------------------

def make_osrm_response(distance_m: float = 15_000, duration_s: float = 1_800) -> dict:
    return {
        "code": "Ok",
        "routes": [{
            "distance": distance_m,
            "duration": duration_s,
            "geometry": {
                "type": "LineString",
                "coordinates": [[90.3, 23.8], [91.8, 24.9]],
            },
        }],
    }


class MockResponse:
    def __init__(self, data: dict, status_code: int = 200):
        self._data = data
        self.status_code = status_code

    def json(self):
        return self._data


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

DHAKA  = GeoPoint(latitude=23.8000, longitude=90.3700)
SYLHET = GeoPoint(latitude=24.8949, longitude=91.8687)


# ---------------------------------------------------------------------------
# Boat routing tests (no OSRM call expected)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_boat_uses_straight_line_not_osrm():
    """Rescue boats must NOT call OSRM — straight-line only."""
    router = RouteComputer(osrm_url="http://fake-osrm:5000")

    with patch("httpx.AsyncClient") as mock_client:
        team = await router.compute_for_resource(
            unit_id=uuid4(),
            unit_name="Boat-Test",
            resource_type="rescue_boat",
            origin=DHAKA,
            destination=SYLHET,
        )
        # httpx should never have been called
        mock_client.assert_not_called()

    assert team.transport_mode == TransportMode.WATERWAY
    assert team.distance_km > 0
    assert team.eta_minutes > 0
    assert team.route_geometry is not None
    assert team.route_geometry["type"] == "LineString"


@pytest.mark.asyncio
async def test_boat_eta_uses_correct_speed():
    """Boat ETA = distance / speed * 60. Check with default flood_shallow speed."""
    from shared.geo_utils import haversine_km

    router = RouteComputer()
    team = await router.compute_for_resource(
        unit_id=uuid4(),
        unit_name="Boat-Speed",
        resource_type="rescue_boat",
        origin=DHAKA,
        destination=SYLHET,
        flood_severity="flood_shallow",
    )
    expected_dist = haversine_km(
        DHAKA.latitude, DHAKA.longitude,
        SYLHET.latitude, SYLHET.longitude,
    )
    expected_eta  = (expected_dist / BOAT_SPEEDS["flood_shallow"]) * 60

    assert abs(team.distance_km - expected_dist) < 0.01
    assert abs(team.eta_minutes - expected_eta) < 0.1


@pytest.mark.asyncio
async def test_boat_severe_flood_slower():
    """Boat ETA under flood_severe should be longer than flood_shallow."""
    router = RouteComputer()
    team_shallow = await router.compute_for_resource(
        uuid4(), "B1", "rescue_boat", DHAKA, SYLHET, flood_severity="flood_shallow"
    )
    team_severe = await router.compute_for_resource(
        uuid4(), "B2", "rescue_boat", DHAKA, SYLHET, flood_severity="flood_severe"
    )
    assert team_severe.eta_minutes > team_shallow.eta_minutes


@pytest.mark.asyncio
async def test_boat_geojson_uses_lon_lat_order():
    """GeoJSON LineString coordinates must be [longitude, latitude] per spec."""
    router = RouteComputer()
    team = await router.compute_for_resource(
        uuid4(), "B1", "rescue_boat", DHAKA, SYLHET
    )
    coords = team.route_geometry["coordinates"]
    # First coord = origin: [lon, lat]
    assert coords[0][0] == pytest.approx(DHAKA.longitude, abs=0.001)
    assert coords[0][1] == pytest.approx(DHAKA.latitude,  abs=0.001)
    # Last coord = destination
    assert coords[-1][0] == pytest.approx(SYLHET.longitude, abs=0.001)
    assert coords[-1][1] == pytest.approx(SYLHET.latitude,  abs=0.001)


# ---------------------------------------------------------------------------
# Road routing tests (OSRM mocked)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_road_route_calls_osrm():
    """Medical teams must use OSRM for road routing."""
    osrm_response = make_osrm_response(distance_m=15_000, duration_s=1_800)

    mock_resp = MockResponse(osrm_response)
    with patch("httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        instance.__aenter__ = AsyncMock(return_value=instance)
        instance.__aexit__  = AsyncMock(return_value=False)
        instance.get        = AsyncMock(return_value=mock_resp)
        MockClient.return_value = instance

        router = RouteComputer(osrm_url="http://fake-osrm:5000")
        team = await router.compute_for_resource(
            unit_id=uuid4(),
            unit_name="MedTeam-Dhaka-1",
            resource_type="medical_team",
            origin=DHAKA,
            destination=SYLHET,
        )

    assert team.transport_mode == TransportMode.ROAD
    assert team.distance_km  == pytest.approx(15.0, abs=0.01)
    assert team.eta_minutes  == pytest.approx(30.0, abs=0.01)
    assert team.route_geometry is not None
    assert team.route_geometry["type"] == "LineString"


@pytest.mark.asyncio
async def test_road_route_uses_correct_osrm_coordinate_order():
    """OSRM URL must have coordinates in longitude,latitude order."""
    captured_url = []

    async def mock_get(url, **kwargs):
        captured_url.append(url)
        return MockResponse(make_osrm_response())

    with patch("httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        instance.__aenter__ = AsyncMock(return_value=instance)
        instance.__aexit__  = AsyncMock(return_value=False)
        instance.get        = AsyncMock(side_effect=mock_get)
        MockClient.return_value = instance

        router = RouteComputer(osrm_url="http://osrm:5000")
        await router.compute_for_resource(
            uuid4(), "Med-1", "medical_team", DHAKA, SYLHET
        )

    url = captured_url[0]
    # URL should contain origin as "lon,lat" — Dhaka longitude first
    assert f"{DHAKA.longitude},{DHAKA.latitude}" in url
    assert f"{SYLHET.longitude},{SYLHET.latitude}" in url


@pytest.mark.asyncio
async def test_road_route_osrm_failure_uses_fallback():
    """If OSRM is unreachable, route_computer should fall back to straight-line."""
    with patch("httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        instance.__aenter__ = AsyncMock(return_value=instance)
        instance.__aexit__  = AsyncMock(return_value=False)
        instance.get        = AsyncMock(side_effect=httpx.ConnectError("connection refused"))
        MockClient.return_value = instance

        router = RouteComputer(osrm_url="http://unreachable:5000")
        team = await router.compute_for_resource(
            uuid4(), "Med-Fallback", "medical_team", DHAKA, SYLHET
        )

    # Should still return a valid TeamAssignment, not raise
    assert team.transport_mode == TransportMode.ROAD
    assert team.distance_km > 0
    assert team.eta_minutes > 0
    # Fallback geometry is a straight line
    assert team.route_geometry["type"] == "LineString"


@pytest.mark.asyncio
async def test_food_supply_uses_road_transport():
    """food_supply is road-bound, not waterway."""
    osrm_response = make_osrm_response()
    mock_resp = MockResponse(osrm_response)
    with patch("httpx.AsyncClient") as MockClient:
        instance = AsyncMock()
        instance.__aenter__ = AsyncMock(return_value=instance)
        instance.__aexit__  = AsyncMock(return_value=False)
        instance.get        = AsyncMock(return_value=mock_resp)
        MockClient.return_value = instance

        router = RouteComputer()
        team = await router.compute_for_resource(
            uuid4(), "Food-Truck-1", "food_supply", DHAKA, SYLHET
        )

    assert team.transport_mode == TransportMode.ROAD


@pytest.mark.asyncio
async def test_multiple_resource_types_correct_modes():
    """Verify transport mode assignment for every resource type."""
    router = RouteComputer()

    # All road types
    road_types = ["medical_team", "medical_kit", "food_supply", "water_supply"]
    for rtype in road_types:
        osrm_response = make_osrm_response()
        mock_resp = MockResponse(osrm_response)
        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__  = AsyncMock(return_value=False)
            instance.get        = AsyncMock(return_value=mock_resp)
            MockClient.return_value = instance

            team = await router.compute_for_resource(
                uuid4(), f"{rtype}-unit", rtype, DHAKA, SYLHET
            )
        assert team.transport_mode == TransportMode.ROAD, f"Expected ROAD for {rtype}"

    # Boat type — no OSRM call
    team = await router.compute_for_resource(
        uuid4(), "rescue-boat-unit", "rescue_boat", DHAKA, SYLHET
    )
    assert team.transport_mode == TransportMode.WATERWAY

"""
Tests for Agent 4 — RouteSafetyChecker
Uses in-memory fallback (no PostGIS required).
Run with: pytest tests/test_safety_checker.py -v
"""
import pytest

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../../"))

from src.agents.agent_4_dispatch.safety_checker import RouteSafetyChecker, SEVERITY_SAFETY


# ---------------------------------------------------------------------------
# Sample geometries
# ---------------------------------------------------------------------------

# Straight line Dhaka → Sylhet (approximate)
DHAKA_SYLHET_LINE = {
    "type": "LineString",
    "coordinates": [
        [90.37, 23.80],   # Dhaka  [lon, lat]
        [91.87, 24.89],   # Sylhet [lon, lat]
    ],
}

# Short local line near Dhaka
DHAKA_LOCAL_LINE = {
    "type": "LineString",
    "coordinates": [
        [90.37, 23.80],
        [90.40, 23.83],
    ],
}


# ---------------------------------------------------------------------------
# In-memory fallback tests (no DB)
# ---------------------------------------------------------------------------

def make_checker_no_db():
    return RouteSafetyChecker(db_pool=None)


def test_no_geometry_returns_1():
    """None geometry (boat straight-line) → always safe."""
    checker = make_checker_no_db()
    score = checker._check_in_memory(None, [])
    assert score == 1.0


def test_clear_route_returns_1():
    """Route that doesn't intersect any flood zone → 1.0."""
    checker = make_checker_no_db()
    # Flood zone far from the Dhaka-Sylhet line
    zones = [{"center_lat": 22.0, "center_lon": 89.0, "radius_km": 5.0, "risk_level": "high"}]
    score = checker._check_in_memory(DHAKA_SYLHET_LINE, zones)
    assert score == 1.0


def test_high_zone_intersection_returns_low_score():
    """Route through HIGH zone → 0.3."""
    checker = make_checker_no_db()
    # Zone centred exactly on Dhaka (route starts there)
    zones = [{"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "high"}]
    score = checker._check_in_memory(DHAKA_SYLHET_LINE, zones)
    assert score == pytest.approx(SEVERITY_SAFETY["high"])


def test_moderate_zone_intersection():
    """Route through MODERATE zone → 0.6."""
    checker = make_checker_no_db()
    zones = [{"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "moderate"}]
    score = checker._check_in_memory(DHAKA_LOCAL_LINE, zones)
    assert score == pytest.approx(SEVERITY_SAFETY["moderate"])


def test_multiple_zones_returns_minimum():
    """Multiple intersecting zones → minimum score wins."""
    checker = make_checker_no_db()
    zones = [
        {"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "moderate"},  # 0.6
        {"center_lat": 24.89, "center_lon": 91.87, "radius_km": 10.0, "risk_level": "critical"},  # 0.3
    ]
    score = checker._check_in_memory(DHAKA_SYLHET_LINE, zones)
    assert score == pytest.approx(SEVERITY_SAFETY["critical"])


def test_critical_zone_same_as_high():
    """CRITICAL and HIGH both map to 0.3 (same penalty)."""
    assert SEVERITY_SAFETY["critical"] == SEVERITY_SAFETY["high"] == 0.3


def test_unknown_severity_defaults_to_mid():
    """Unrecognised severity level falls back to 0.5."""
    checker = make_checker_no_db()
    zones = [{"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "unknown_level"}]
    score = checker._check_in_memory(DHAKA_LOCAL_LINE, zones)
    assert score == pytest.approx(0.5)


def test_empty_flood_zones_returns_1():
    """No flood zones → safe."""
    checker = make_checker_no_db()
    score = checker._check_in_memory(DHAKA_SYLHET_LINE, [])
    assert score == 1.0


# ---------------------------------------------------------------------------
# Async check() — PostGIS path falls back when DB is None
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_async_check_none_geometry():
    """check(None) → 1.0 immediately, no DB call."""
    checker = make_checker_no_db()
    score = await checker.check(route_geometry=None)
    assert score == 1.0


@pytest.mark.asyncio
async def test_async_check_uses_fallback_when_db_none():
    """check() with db_pool=None falls back to in-memory check."""
    checker = make_checker_no_db()
    zones = [{"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "high"}]
    score = await checker.check(
        route_geometry=DHAKA_LOCAL_LINE,
        active_flood_zones=zones,
    )
    assert score == pytest.approx(SEVERITY_SAFETY["high"])


@pytest.mark.asyncio
async def test_async_check_postgis_failure_falls_back():
    """If PostGIS query raises, fall back to in-memory result gracefully."""
    class BrokenPool:
        async def fetch(self, *args, **kwargs):
            raise ConnectionError("DB down")

    checker = RouteSafetyChecker(db_pool=BrokenPool())
    zones = [{"center_lat": 23.80, "center_lon": 90.37, "radius_km": 10.0, "risk_level": "moderate"}]
    # Should not raise — should fall back
    score = await checker.check(
        route_geometry=DHAKA_LOCAL_LINE,
        active_flood_zones=zones,
    )
    assert 0.0 <= score <= 1.0

"""
Pydantic models for Agent 4 — Dispatch Optimization.
"""
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class TransportMode(str, Enum):
    ROAD     = "road"       # Medical teams / trucks → OSRM
    WATERWAY = "waterway"   # Rescue boats → straight-line


class TeamStatus(str, Enum):
    DISPATCHED = "dispatched"
    EN_ROUTE   = "en_route"
    ARRIVED    = "arrived"
    RETURNING  = "returning"


class GeoPoint(BaseModel):
    latitude:  float = Field(..., ge=-90,  le=90)
    longitude: float = Field(..., ge=-180, le=180)


class TeamAssignment(BaseModel):
    """Route plan for a single resource unit."""

    unit_id:        UUID
    unit_name:      str
    resource_type:  str
    transport_mode: TransportMode
    origin:         GeoPoint
    destination:    GeoPoint
    # GeoJSON LineString from OSRM or straight-line helper
    route_geometry: Optional[dict] = None
    distance_km:    float
    eta_minutes:    float
    status:         TeamStatus = TeamStatus.DISPATCHED
    departed_at:    Optional[datetime] = None
    arrived_at:     Optional[datetime] = None


class RouteAssignment(BaseModel):
    """
    Complete dispatch plan for one incident.
    Published on the route_assignment Redis channel → Dashboard.
    """
    assignment_id:      UUID     = Field(default_factory=uuid4)
    timestamp:          datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    incident_id:        str
    zone_id:            str
    zone_name:          str
    destination:        GeoPoint
    priority:           int
    teams:              List[TeamAssignment]
    total_eta_minutes:  float       # slowest team
    route_safety_score: float       # 0.0 = flooded, 1.0 = clear
    notes:              str = ""


class RouteStatusUpdate(BaseModel):
    """Body for POST /teams/{id}/status."""
    status:     TeamStatus
    timestamp:  datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

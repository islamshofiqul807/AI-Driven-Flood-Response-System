"""
Route Computer — OSRM road routing + straight-line boat estimation.

Coordinate order reminder:
  Pydantic models  → (latitude, longitude)
  OSRM URL params  → longitude,latitude  (x,y)
  GeoJSON          → [longitude, latitude]
"""
import logging
from typing import Optional

import httpx

from shared.geo_utils import haversine_km, straight_line_geojson

from .models import GeoPoint, TeamAssignment, TransportMode

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Boat speed table (km/h)
# ---------------------------------------------------------------------------
BOAT_SPEEDS = {
    "normal_river":  15.0,
    "flood_shallow": 10.0,
    "flood_deep":     8.0,
    "flood_severe":   5.0,
}
DEFAULT_BOAT_SPEED = 10.0  # km/h — conservative flood-water default

# Road-bound resource types
ROAD_TRANSPORT_TYPES = {"medical_team", "medical_kit", "food_supply", "water_supply"}
BOAT_TRANSPORT_TYPES = {"rescue_boat"}


class RouteComputer:
    """
    Computes routes for individual TeamAssignments.
    - Boats:  straight-line distance / speed → no OSRM call
    - Others: OSRM driving route (Bangladesh road network)
    """

    def __init__(self, osrm_url: str = "http://osrm:5000"):
        self.osrm_url = osrm_url.rstrip("/")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def compute_for_resource(
        self,
        unit_id,
        unit_name: str,
        resource_type: str,
        origin: GeoPoint,
        destination: GeoPoint,
        flood_severity: str = "flood_shallow",
    ) -> TeamAssignment:
        """
        Compute route for one resource unit and return a TeamAssignment.
        """
        if resource_type in BOAT_TRANSPORT_TYPES:
            return await self._boat_route(
                unit_id, unit_name, resource_type,
                origin, destination, flood_severity,
            )
        return await self._road_route(
            unit_id, unit_name, resource_type, origin, destination
        )

    # ------------------------------------------------------------------
    # Boat routing (straight-line)
    # ------------------------------------------------------------------

    async def _boat_route(
        self,
        unit_id, unit_name, resource_type,
        origin: GeoPoint,
        destination: GeoPoint,
        flood_severity: str,
    ) -> TeamAssignment:
        distance_km = haversine_km(
            origin.latitude, origin.longitude,
            destination.latitude, destination.longitude,
        )
        speed = BOAT_SPEEDS.get(flood_severity, DEFAULT_BOAT_SPEED)
        eta_minutes = (distance_km / speed) * 60.0

        geometry = straight_line_geojson(
            origin.latitude, origin.longitude,
            destination.latitude, destination.longitude,
        )

        logger.debug(
            "Boat route %s → %.2f km @ %.1f km/h = %.1f min",
            unit_name, distance_km, speed, eta_minutes,
        )
        return TeamAssignment(
            unit_id=unit_id,
            unit_name=unit_name,
            resource_type=resource_type,
            transport_mode=TransportMode.WATERWAY,
            origin=origin,
            destination=destination,
            route_geometry=geometry,
            distance_km=distance_km,
            eta_minutes=eta_minutes,
        )

    # ------------------------------------------------------------------
    # Road routing (OSRM)
    # ------------------------------------------------------------------

    async def _road_route(
        self,
        unit_id, unit_name, resource_type,
        origin: GeoPoint,
        destination: GeoPoint,
    ) -> TeamAssignment:
        url = (
            f"{self.osrm_url}/route/v1/driving/"
            f"{origin.longitude},{origin.latitude};"
            f"{destination.longitude},{destination.latitude}"
            f"?overview=full&geometries=geojson&steps=false"
        )
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(url)
                data = resp.json()

            if data.get("code") != "Ok" or not data.get("routes"):
                raise ValueError(f"OSRM returned code={data.get('code')}")

            route      = data["routes"][0]
            distance_km = route["distance"] / 1000.0
            eta_minutes = route["duration"] / 60.0
            geometry    = route["geometry"]   # GeoJSON LineString

            logger.debug(
                "Road route %s → %.2f km, %.1f min (OSRM)",
                unit_name, distance_km, eta_minutes,
            )

        except Exception as exc:
            # Fallback: straight-line if OSRM unavailable
            logger.warning("OSRM unavailable (%s) — using straight-line fallback", exc)
            distance_km = haversine_km(
                origin.latitude, origin.longitude,
                destination.latitude, destination.longitude,
            )
            # Assume 30 km/h average road speed as conservative estimate
            eta_minutes = (distance_km / 30.0) * 60.0
            geometry = straight_line_geojson(
                origin.latitude, origin.longitude,
                destination.latitude, destination.longitude,
            )

        return TeamAssignment(
            unit_id=unit_id,
            unit_name=unit_name,
            resource_type=resource_type,
            transport_mode=TransportMode.ROAD,
            origin=origin,
            destination=destination,
            route_geometry=geometry,
            distance_km=distance_km,
            eta_minutes=eta_minutes,
        )

    # ------------------------------------------------------------------
    # OSRM distance matrix (utility — used for pre-sorting if needed)
    # ------------------------------------------------------------------

    async def get_matrix(
        self, origins: list[GeoPoint], destinations: list[GeoPoint]
    ) -> Optional[dict]:
        all_points = origins + destinations
        coords_str = ";".join(
            f"{p.longitude},{p.latitude}" for p in all_points
        )
        sources_str = ";".join(str(i) for i in range(len(origins)))
        dests_str   = ";".join(
            str(i) for i in range(len(origins), len(origins) + len(destinations))
        )
        url = (
            f"{self.osrm_url}/table/v1/driving/{coords_str}"
            f"?sources={sources_str}&destinations={dests_str}"
        )
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(url)
                return resp.json()
        except Exception as exc:
            logger.error("OSRM matrix request failed: %s", exc)
            return None

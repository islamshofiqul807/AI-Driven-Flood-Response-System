"""
Route Safety Checker.

Uses PostGIS ST_Intersects to check whether a route's LineString
passes through active flood zones.

Safety score:
  1.0 → clear route
  0.6 → passes through MODERATE zone
  0.3 → passes through HIGH or CRITICAL zone
  (minimum score across all intersections)
"""
import json
import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

# Severity → safety penalty
SEVERITY_SAFETY = {
    "minimal":  1.0,
    "low":      0.9,
    "moderate": 0.6,
    "high":     0.3,
    "critical": 0.3,
}


class RouteSafetyChecker:
    """Check route safety against active flood zones stored in PostGIS."""

    def __init__(self, db_pool):
        self.pool = db_pool

    async def check(
        self,
        route_geometry: Optional[dict],
        active_flood_zones: Optional[List[dict]] = None,
    ) -> float:
        """
        Return a safety score 0.0–1.0.
        If route_geometry is None (e.g. boat straight-line), return 1.0.
        Falls back to in-memory check if DB unavailable.
        """
        if route_geometry is None:
            return 1.0

        try:
            return await self._check_via_postgis(route_geometry)
        except Exception as exc:
            logger.warning("PostGIS safety check failed (%s) — using fallback", exc)
            return self._check_in_memory(route_geometry, active_flood_zones or [])

    # ------------------------------------------------------------------
    # PostGIS path
    # ------------------------------------------------------------------

    async def _check_via_postgis(self, route_geometry: dict) -> float:
        """
        Query satellite_imagery_detections (Agent 1's table) for flood zones
        that intersect the route LineString.
        """
        geojson_str = json.dumps(route_geometry)

        rows = await self.pool.fetch(
            """
            SELECT DISTINCT risk_level
            FROM satellite_imagery_detections
            WHERE status = 'active'
              AND ST_Intersects(
                    flood_boundary,
                    ST_GeomFromGeoJSON($1)::geography
                  )
            """,
            geojson_str,
        )

        if not rows:
            return 1.0

        min_score = 1.0
        for row in rows:
            severity = row["risk_level"].lower()
            score = SEVERITY_SAFETY.get(severity, 0.5)
            min_score = min(min_score, score)
            logger.debug("Route intersects %s zone → score %.1f", severity, score)

        return min_score

    # ------------------------------------------------------------------
    # In-memory fallback (used when DB unreachable or in unit tests)
    # ------------------------------------------------------------------

    def _check_in_memory(
        self,
        route_geometry: dict,
        flood_zones: List[dict],
    ) -> float:
        """
        Naive bounding-box intersection fallback.
        flood_zones: list of dicts with {center_lat, center_lon, radius_km, risk_level}
        """
        from shared.geo_utils import haversine_km, linestring_coords

        coords = linestring_coords(route_geometry)
        if not coords:
            return 1.0

        min_score = 1.0
        for zone in flood_zones:
            clat = zone.get("center_lat", zone.get("center", {}).get("latitude", 0))
            clon = zone.get("center_lon", zone.get("center", {}).get("longitude", 0))
            radius = zone.get("radius_km", 5.0)
            severity = zone.get("risk_level", "moderate").lower()

            for lon, lat in coords:
                dist = haversine_km(lat, lon, clat, clon)
                if dist <= radius:
                    score = SEVERITY_SAFETY.get(severity, 0.5)
                    min_score = min(min_score, score)
                    break  # one hit per zone is enough

        return min_score

"""
Agent 4 — Dispatch Optimization
FastAPI service on port 8004 (mapped from 8000 inside Docker).
"""
import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional

import asyncpg
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from redis import asyncio as aioredis

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../"))

from .models import RouteStatusUpdate, TeamStatus
from .redis_handler import Agent4RedisHandler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("agent_4_dispatch")

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://disaster_admin:disaster123@localhost:5432/disaster_response",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
OSRM_URL  = os.getenv("OSRM_URL",  "http://osrm:5000")
AGENT_PORT = int(os.getenv("AGENT_PORT", "8000"))

db_pool: Optional[asyncpg.Pool] = None
redis_client = None
handler: Optional[Agent4RedisHandler] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool, redis_client, handler

    db_pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=10)
    logger.info("PostgreSQL connected")

    redis_client = await aioredis.from_url(REDIS_URL, decode_responses=True)
    logger.info("Redis connected")

    handler = Agent4RedisHandler(redis_client, db_pool, OSRM_URL)
    asyncio.create_task(handler.start_listening())
    asyncio.create_task(handler.publish_heartbeat())
    logger.info("Agent 4 listening on dispatch_order (OSRM: %s)", OSRM_URL)

    yield

    await db_pool.close()
    await redis_client.aclose()


app = FastAPI(
    title="Agent 4 — Dispatch Optimization",
    description="Route planning and team dispatch for disaster response.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
async def root():
    return {
        "agent": "agent_4_dispatch",
        "version": "1.0.0",
        "subscribes_to": ["dispatch_order"],
        "publishes_to":  ["route_assignment", "agent_status"],
        "osrm_url":      OSRM_URL,
    }


@app.get("/health")
async def health():
    try:
        await db_pool.fetchval("SELECT 1")
        await redis_client.ping()
        return {"status": "healthy", "db": "ok", "redis": "ok", "osrm": OSRM_URL}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.get("/routes")
async def get_routes(status: str = "active", limit: int = 20):
    rows = await db_pool.fetch(
        """
        SELECT id, timestamp, incident_id, zone_name, priority,
               total_eta_minutes, route_safety_score, status
        FROM dispatch_routes
        WHERE status = $1
        ORDER BY timestamp DESC
        LIMIT $2
        """,
        status, limit,
    )
    return [dict(r) for r in rows]


@app.get("/routes/{route_id}")
async def get_route(route_id: str):
    row = await db_pool.fetchrow(
        "SELECT * FROM dispatch_routes WHERE id = $1::uuid", route_id
    )
    if not row:
        raise HTTPException(status_code=404, detail="Route not found")

    teams = await db_pool.fetch(
        "SELECT * FROM team_routes WHERE dispatch_id = $1::uuid ORDER BY eta_minutes",
        route_id,
    )
    result = dict(row)
    result["teams"] = [dict(t) for t in teams]
    return result


@app.get("/routes/{route_id}/geojson")
async def get_route_geojson(route_id: str):
    """Return a GeoJSON FeatureCollection of all team routes for map rendering."""
    teams = await db_pool.fetch(
        """
        SELECT unit_name, resource_type, transport_mode,
               route_geometry, eta_minutes, distance_km, status
        FROM team_routes WHERE dispatch_id = $1::uuid
        """,
        route_id,
    )
    if not teams:
        raise HTTPException(status_code=404, detail="Route not found")

    features = []
    for t in teams:
        geom = json.loads(t["route_geometry"]) if t["route_geometry"] else None
        if geom:
            features.append({
                "type": "Feature",
                "geometry": geom,
                "properties": {
                    "unit_name":      t["unit_name"],
                    "resource_type":  t["resource_type"],
                    "transport_mode": t["transport_mode"],
                    "eta_minutes":    t["eta_minutes"],
                    "distance_km":    t["distance_km"],
                    "status":         t["status"],
                },
            })

    return JSONResponse(content={
        "type": "FeatureCollection",
        "features": features,
    })


@app.get("/teams")
async def get_teams(limit: int = 50):
    rows = await db_pool.fetch(
        """
        SELECT tr.id, tr.unit_name, tr.resource_type, tr.transport_mode,
               tr.eta_minutes, tr.distance_km, tr.status,
               tr.departed_at, tr.arrived_at,
               dr.zone_name, dr.priority
        FROM team_routes tr
        JOIN dispatch_routes dr ON dr.id = tr.dispatch_id
        WHERE dr.status = 'active'
        ORDER BY tr.eta_minutes
        LIMIT $1
        """,
        limit,
    )
    return [dict(r) for r in rows]


@app.get("/teams/{team_id}")
async def get_team(team_id: str):
    row = await db_pool.fetchrow(
        "SELECT * FROM team_routes WHERE id = $1::uuid", team_id
    )
    if not row:
        raise HTTPException(status_code=404, detail="Team route not found")
    return dict(row)


@app.post("/teams/{team_id}/status")
async def update_team_status(team_id: str, update: RouteStatusUpdate):
    """Mark a team as arrived, returning, etc."""
    extra_sql = ""
    if update.status == TeamStatus.ARRIVED:
        extra_sql = ", arrived_at = NOW()"
    elif update.status == TeamStatus.EN_ROUTE:
        extra_sql = ", departed_at = NOW()"

    result = await db_pool.execute(
        f"UPDATE team_routes SET status = $2 {extra_sql} WHERE id = $1::uuid",
        team_id, update.status.value,
    )
    if result == "UPDATE 0":
        raise HTTPException(status_code=404, detail="Team route not found")
    return {"updated": True, "status": update.status.value}


@app.post("/trigger")
async def trigger_route(dispatch_order: dict):
    """Manually trigger route computation (for testing without Agent 3)."""
    if not handler:
        raise HTTPException(status_code=503, detail="Handler not ready")
    from shared.message_protocol import AgentMessage
    fake_envelope = AgentMessage(
        sender_agent="manual",
        receiver_agent="agent_4_dispatch",
        message_type="dispatch_order",
        zone_id=dispatch_order.get("zone_id"),
        priority=dispatch_order.get("priority", 3),
        payload=dispatch_order,
    )
    await handler._handle_dispatch_order(fake_envelope)
    return {"triggered": True}


@app.get("/status")
async def status():
    if not handler:
        return {"status": "starting"}
    uptime = (datetime.now(timezone.utc) - handler._start_time).total_seconds()
    return {
        "status":      "running",
        "uptime_s":    uptime,
        "last_action": handler._last_action,
        "osrm_url":    OSRM_URL,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "src.agents.agent_4_dispatch.main:app",
        host="0.0.0.0",
        port=AGENT_PORT,
        reload=False,
    )

"""
Redis handler for Agent 4 — Dispatch Optimization.
Subscribes to:  dispatch_order   (from Agent 3)
Publishes to:   route_assignment (to Dashboard)
                agent_status     (heartbeat)
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from shared.message_protocol import (
    AgentMessage,
    HeartbeatMessage,
    listen_for_messages,
    log_message_to_db,
    publish_message,
)

from .models import GeoPoint, RouteAssignment, TeamAssignment
from .route_computer import RouteComputer
from .safety_checker import RouteSafetyChecker

logger = logging.getLogger(__name__)

AGENT_ID = "agent_4_dispatch"


class Agent4RedisHandler:
    def __init__(self, redis_client, db_pool, osrm_url: str):
        self.redis   = redis_client
        self.db      = db_pool
        self.router  = RouteComputer(osrm_url)
        self.safety  = RouteSafetyChecker(db_pool)
        self._start_time  = datetime.now(timezone.utc)
        self._last_action = "initialized"

    # ------------------------------------------------------------------
    # Subscriber
    # ------------------------------------------------------------------

    async def start_listening(self):
        await listen_for_messages(
            self.redis, "dispatch_order", self._handle_dispatch_order
        )

    async def _handle_dispatch_order(self, envelope: AgentMessage):
        logger.info(
            "Received dispatch_order from %s | zone=%s | priority=%d",
            envelope.sender_agent, envelope.zone_id, envelope.priority,
        )
        self._last_action = f"received dispatch_order zone={envelope.zone_id}"

        allocation = envelope.payload
        destination = GeoPoint(**allocation["destination"])

        teams: list[TeamAssignment] = []
        safety_scores: list[float]  = []

        for resource in allocation.get("allocated_resources", []):
            origin = GeoPoint(**resource["current_location"])
            team = await self.router.compute_for_resource(
                unit_id=UUID(resource["unit_id"]),
                unit_name=resource["name"],
                resource_type=resource["type"],
                origin=origin,
                destination=destination,
            )

            score = await self.safety.check(team.route_geometry)
            safety_scores.append(score)
            teams.append(team)

        if not teams:
            logger.warning("No teams to dispatch for incident %s", allocation.get("incident_id"))
            return

        total_eta    = max(t.eta_minutes for t in teams)
        safety_score = min(safety_scores) if safety_scores else 1.0

        assignment = RouteAssignment(
            incident_id=allocation["incident_id"],
            zone_id=allocation["zone_id"],
            zone_name=allocation.get("zone_name", "Unknown"),
            destination=destination,
            priority=allocation.get("priority", 3),
            teams=teams,
            total_eta_minutes=total_eta,
            route_safety_score=safety_score,
            notes=(
                f"Route safety: {safety_score:.0%}. "
                f"{len(teams)} units dispatched. "
                f"Slowest ETA: {total_eta:.0f} min."
            ),
        )

        await self._save_to_db(assignment, allocation.get("allocation_id"))
        await self._update_team_statuses(teams)
        await self._publish_route_assignment(assignment)

    # ------------------------------------------------------------------
    # DB writes
    # ------------------------------------------------------------------

    async def _save_to_db(self, assignment: RouteAssignment, allocation_id: Optional[str]):
        dispatch_id = assignment.assignment_id
        await self.db.execute(
            """
            INSERT INTO dispatch_routes
                (id, timestamp, allocation_id, incident_id, zone_id, zone_name,
                 destination, priority, total_eta_minutes, route_safety_score, status)
            VALUES ($1, $2, $3::uuid, $4, $5, $6,
                    ST_SetSRID(ST_MakePoint($8, $7), 4326),
                    $9, $10, $11, 'active')
            """,
            dispatch_id,
            assignment.timestamp,
            allocation_id,
            assignment.incident_id,
            assignment.zone_id,
            assignment.zone_name,
            assignment.destination.latitude,
            assignment.destination.longitude,
            assignment.priority,
            assignment.total_eta_minutes,
            assignment.route_safety_score,
        )

        for team in assignment.teams:
            await self.db.execute(
                """
                INSERT INTO team_routes
                    (dispatch_id, unit_id, unit_name, resource_type,
                     transport_mode, origin, destination,
                     route_geometry, distance_km, eta_minutes,
                     status, departed_at)
                VALUES ($1, $2, $3, $4, $5,
                        ST_SetSRID(ST_MakePoint($7, $6), 4326),
                        ST_SetSRID(ST_MakePoint($9, $8), 4326),
                        $10, $11, $12, 'dispatched', NOW())
                """,
                dispatch_id,
                team.unit_id,
                team.unit_name,
                team.resource_type,
                team.transport_mode.value,
                team.origin.latitude,
                team.origin.longitude,
                team.destination.latitude,
                team.destination.longitude,
                json.dumps(team.route_geometry) if team.route_geometry else None,
                team.distance_km,
                team.eta_minutes,
            )

        logger.info("Saved dispatch %s to DB (%d teams)", dispatch_id, len(assignment.teams))

    async def _update_team_statuses(self, teams: list[TeamAssignment]):
        """Mark dispatched resource units as en_route in resource_units."""
        for team in teams:
            try:
                await self.db.execute(
                    "UPDATE resource_units SET status = 'deployed', updated_at = NOW() WHERE id = $1",
                    team.unit_id,
                )
            except Exception as exc:
                logger.warning("Could not update status for unit %s: %s", team.unit_id, exc)

    # ------------------------------------------------------------------
    # Publisher
    # ------------------------------------------------------------------

    async def _publish_route_assignment(self, assignment: RouteAssignment):
        message = AgentMessage(
            sender_agent=AGENT_ID,
            receiver_agent="all",
            message_type="route_assignment",
            zone_id=assignment.zone_id,
            priority=assignment.priority,
            payload=assignment.model_dump(mode="json"),
        )
        await publish_message(self.redis, "route_assignment", message)
        await log_message_to_db(self.db, message)
        self._last_action = f"published route_assignment zone={assignment.zone_id}"
        logger.info(
            "Published route_assignment for incident %s | ETA %.0f min | safety %.0f%%",
            assignment.incident_id,
            assignment.total_eta_minutes,
            assignment.route_safety_score * 100,
        )

    async def publish_heartbeat(self):
        while True:
            uptime = (datetime.now(timezone.utc) - self._start_time).total_seconds()
            hb = HeartbeatMessage(
                agent_id=AGENT_ID,
                uptime_seconds=uptime,
                last_action=self._last_action,
            )
            msg = AgentMessage(
                sender_agent=AGENT_ID,
                receiver_agent="all",
                message_type="heartbeat",
                payload=hb.model_dump(mode="json"),
            )
            await publish_message(self.redis, "agent_status", msg)
            await asyncio.sleep(30)

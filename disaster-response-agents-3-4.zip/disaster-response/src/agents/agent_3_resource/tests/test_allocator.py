"""
Tests for Agent 3 — ResourceAllocator
Run with: pytest tests/test_allocator.py -v

These tests use mock InventoryManager so no DB/Redis required.
"""
import asyncio
from datetime import datetime, timezone
from typing import List, Optional
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../../"))

from src.agents.agent_3_resource.allocator import ResourceAllocator, RULES
from src.agents.agent_3_resource.models import (
    GeoPoint,
    ResourceAllocation,
    ResourceStatus,
    ResourceType,
    ResourceUnit,
    UrgencyLevel,
)


# ---------------------------------------------------------------------------
# Fixtures & helpers
# ---------------------------------------------------------------------------

def make_unit(
    resource_type: ResourceType,
    lat: float,
    lon: float,
    name: str = None,
    capacity: int = 15,
) -> ResourceUnit:
    return ResourceUnit(
        id=uuid4(),
        resource_type=resource_type,
        name=name or f"{resource_type.value}-{uuid4().hex[:4]}",
        status=ResourceStatus.AVAILABLE,
        capacity=capacity,
        current_location=GeoPoint(latitude=lat, longitude=lon),
        base_location=GeoPoint(latitude=lat, longitude=lon),
    )


def make_incident(
    urgency: str = UrgencyLevel.LIFE_THREATENING,
    lat: float = 23.8000,
    lon: float = 90.4000,
    num_people: int = 20,
    medical_need: bool = True,
    priority: int = 5,
    zone_id: str = "zone-dhaka-1",
    zone_name: str = "Dhaka North",
) -> dict:
    return {
        "incident_id":  f"INC-{uuid4().hex[:6].upper()}",
        "zone_id":       zone_id,
        "zone_name":     zone_name,
        "location":     {"latitude": lat, "longitude": lon},
        "urgency":       urgency,
        "num_people":    num_people,
        "medical_need":  medical_need,
        "priority":      priority,
    }


class MockInventory:
    """
    Controllable mock InventoryManager.
    Preload it with units via `available_units` dict.
    Deployed units are moved to `deployed`.
    """

    def __init__(self):
        # {ResourceType: [ResourceUnit, ...]}
        self.available_units: dict = {rt: [] for rt in ResourceType}
        self.deployed: List[ResourceUnit] = []
        self.logged_allocations: List[ResourceAllocation] = []

    def seed(self, units: List[ResourceUnit]):
        for u in units:
            self.available_units[u.resource_type].append(u)

    async def get_available(self, resource_type: ResourceType) -> List[ResourceUnit]:
        return list(self.available_units[resource_type])

    async def deploy(self, unit: ResourceUnit, incident_id: str, zone_id: str, triggered_by="agent_3_auto"):
        self.available_units[unit.resource_type] = [
            u for u in self.available_units[unit.resource_type] if u.id != unit.id
        ]
        self.deployed.append(unit)

    async def log_allocation(self, allocation: ResourceAllocation):
        self.logged_allocations.append(allocation)

    async def snapshot(self):
        from src.agents.agent_3_resource.models import InventorySnapshot
        return InventorySnapshot(
            timestamp=datetime.now(timezone.utc),
            resources={},
        )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_life_threatening_gets_boats_and_medical():
    """LIFE_THREATENING incident must receive 2 boats + 1 medical team + 2 kits."""
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37, "Boat-1"),
        make_unit(ResourceType.RESCUE_BOAT,  23.71, 90.41, "Boat-2"),
        make_unit(ResourceType.MEDICAL_TEAM, 23.75, 90.38, "MedTeam-1"),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-1"),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-2"),
    ])

    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.LIFE_THREATENING)
    result    = await allocator.allocate(incident)

    assert result is not None
    assert result.partial_allocation is False
    assert result.requires_medical is True

    types = [r["type"] for r in result.allocated_resources]
    assert types.count("rescue_boat")  == 2
    assert types.count("medical_team") == 1
    assert types.count("medical_kit")  == 2

    # All 5 units should be marked deployed in the mock
    assert len(inv.deployed) == 5


@pytest.mark.asyncio
async def test_urgent_medical_allocation():
    """URGENT + medical_need → 1 boat + 1 medical_team + 1 kit."""
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37),
        make_unit(ResourceType.MEDICAL_TEAM, 23.75, 90.38),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41),
    ])
    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.URGENT, medical_need=True, priority=4)
    result    = await allocator.allocate(incident)

    assert result is not None
    assert result.partial_allocation is False
    types = [r["type"] for r in result.allocated_resources]
    assert "rescue_boat"  in types
    assert "medical_team" in types
    assert "medical_kit"  in types
    assert "food_supply"  not in types


@pytest.mark.asyncio
async def test_urgent_no_medical_allocation():
    """URGENT + no medical → 1 boat + 1 food + 1 water."""
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37),
        make_unit(ResourceType.FOOD_SUPPLY,  23.78, 90.41),
        make_unit(ResourceType.WATER_SUPPLY, 23.78, 90.41),
    ])
    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.URGENT, medical_need=False, priority=3)
    result    = await allocator.allocate(incident)

    assert result is not None
    types = [r["type"] for r in result.allocated_resources]
    assert "rescue_boat"  in types
    assert "food_supply"  in types
    assert "water_supply" in types
    assert "medical_team" not in types


@pytest.mark.asyncio
async def test_moderate_allocation():
    """MODERATE → only food + water, no boats."""
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.FOOD_SUPPLY,  23.78, 90.41),
        make_unit(ResourceType.WATER_SUPPLY, 23.78, 90.41),
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37),  # should NOT be used
    ])
    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.MODERATE, priority=2)
    result    = await allocator.allocate(incident)

    types = [r["type"] for r in result.allocated_resources]
    assert "food_supply"  in types
    assert "water_supply" in types
    assert "rescue_boat"  not in types


@pytest.mark.asyncio
async def test_closest_resource_preferred():
    """Allocator must pick the geographically nearest available boat."""
    # Incident is at Sylhet (24.89, 91.87)
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.RESCUE_BOAT, 23.71, 90.41, "Boat-Dhaka"),     # ~180 km away
        make_unit(ResourceType.RESCUE_BOAT, 24.89, 91.87, "Boat-Sylhet-1"),  # ~0 km
        make_unit(ResourceType.RESCUE_BOAT, 24.90, 91.88, "Boat-Sylhet-2"),  # ~2 km
        make_unit(ResourceType.MEDICAL_TEAM, 24.90, 91.87, "Med-Sylhet"),
        make_unit(ResourceType.MEDICAL_KIT,  24.88, 91.86, "Kit-Sylhet-1"),
        make_unit(ResourceType.MEDICAL_KIT,  24.88, 91.86, "Kit-Sylhet-2"),
    ])
    allocator = ResourceAllocator(inv)
    incident  = make_incident(
        urgency=UrgencyLevel.LIFE_THREATENING,
        lat=24.8949, lon=91.8687,
        zone_name="Sylhet City",
    )
    result = await allocator.allocate(incident)

    boat_names = [
        r["name"] for r in result.allocated_resources if r["type"] == "rescue_boat"
    ]
    # Both selected boats should be the Sylhet ones, NOT Dhaka
    assert "Boat-Dhaka" not in boat_names
    assert "Boat-Sylhet-1" in boat_names
    assert "Boat-Sylhet-2" in boat_names


@pytest.mark.asyncio
async def test_resource_exhaustion_partial_allocation():
    """When boats run out, partial_allocation should be True."""
    inv = MockInventory()
    inv.seed([
        # Only 1 boat available, LIFE_THREATENING needs 2
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37, "OnlyBoat"),
        make_unit(ResourceType.MEDICAL_TEAM, 23.75, 90.38),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-1"),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-2"),
    ])
    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.LIFE_THREATENING)
    result    = await allocator.allocate(incident)

    assert result is not None
    assert result.partial_allocation is True
    boat_count = sum(1 for r in result.allocated_resources if r["type"] == "rescue_boat")
    assert boat_count == 1   # got what was available


@pytest.mark.asyncio
async def test_zero_resources_returns_none():
    """If inventory is completely empty, allocate() should return None."""
    inv = MockInventory()
    # No units seeded
    allocator = ResourceAllocator(inv)
    incident  = make_incident(urgency=UrgencyLevel.LIFE_THREATENING)
    result    = await allocator.allocate(incident)
    assert result is None


@pytest.mark.asyncio
async def test_allocation_logged_to_inventory():
    """Allocation must be logged via inventory.log_allocation()."""
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.FOOD_SUPPLY,  23.78, 90.41),
        make_unit(ResourceType.WATER_SUPPLY, 23.78, 90.41),
    ])
    allocator = ResourceAllocator(inv)
    await allocator.allocate(make_incident(urgency=UrgencyLevel.MODERATE))
    assert len(inv.logged_allocations) == 1


@pytest.mark.asyncio
async def test_process_distress_queue_priority_order():
    """
    process_distress_queue must process higher-priority incidents first.
    After the LIFE_THREATENING incident deploys boats, MODERATE has none left.
    """
    inv = MockInventory()
    inv.seed([
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37, "Boat-A"),
        make_unit(ResourceType.RESCUE_BOAT,  23.80, 90.37, "Boat-B"),
        make_unit(ResourceType.MEDICAL_TEAM, 23.75, 90.38),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-1"),
        make_unit(ResourceType.MEDICAL_KIT,  23.81, 90.41, "Kit-2"),
        make_unit(ResourceType.FOOD_SUPPLY,  23.78, 90.41),
        make_unit(ResourceType.WATER_SUPPLY, 23.78, 90.41),
    ])
    allocator = ResourceAllocator(inv)

    incidents = [
        make_incident(urgency=UrgencyLevel.MODERATE,         priority=1, zone_id="zone-low"),
        make_incident(urgency=UrgencyLevel.LIFE_THREATENING, priority=5, zone_id="zone-high"),
    ]
    results = await allocator.process_distress_queue(incidents)

    # Both should produce allocations (MODERATE only needs food+water)
    assert len(results) == 2
    # First result must be for the higher-priority incident
    assert results[0].priority == 5
    assert results[1].priority == 1

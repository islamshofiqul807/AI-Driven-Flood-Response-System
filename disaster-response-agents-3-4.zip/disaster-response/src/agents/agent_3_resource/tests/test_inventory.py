"""
Tests for Agent 3 — InventoryManager
Uses a lightweight mock DB pool (asyncpg-style).
Run with: pytest tests/test_inventory.py -v
"""
import asyncio
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

import pytest

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../../"))

from src.agents.agent_3_resource.models import GeoPoint, ResourceStatus, ResourceType


# ---------------------------------------------------------------------------
# Minimal asyncpg pool mock
# ---------------------------------------------------------------------------

class FakePool:
    """
    Emulates just enough of asyncpg.Pool for InventoryManager unit tests.
    Tracks calls so tests can inspect what SQL was executed.
    """

    def __init__(self, rows: List[Dict] = None):
        self._rows = rows or []
        self.executed: List[str] = []
        self._fetchval_result = 0

    async def fetch(self, query: str, *args) -> List[Any]:
        self.executed.append(query.strip())
        return self._rows

    async def fetchrow(self, query: str, *args) -> Optional[Any]:
        self.executed.append(query.strip())
        return self._rows[0] if self._rows else None

    async def fetchval(self, query: str, *args):
        self.executed.append(query.strip())
        return self._fetchval_result

    async def execute(self, query: str, *args):
        self.executed.append(query.strip())
        return "UPDATE 1"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_snapshot_builds_correct_structure():
    """snapshot() should call inventory_summary view and return InventorySnapshot."""
    from src.agents.agent_3_resource.inventory_manager import InventoryManager

    fake_rows = [
        {"resource_type": "rescue_boat",  "total": 8, "available": 5, "deployed": 2, "returning": 1, "maintenance": 0},
        {"resource_type": "medical_team", "total": 4, "available": 4, "deployed": 0, "returning": 0, "maintenance": 0},
    ]
    pool = FakePool(rows=fake_rows)
    inv  = InventoryManager(pool)

    snapshot = await inv.snapshot()

    assert "rescue_boat"  in snapshot.resources
    assert "medical_team" in snapshot.resources
    assert snapshot.resources["rescue_boat"]["available"] == 5
    assert snapshot.resources["rescue_boat"]["deployed"]  == 2
    assert snapshot.resources["medical_team"]["total"]    == 4


@pytest.mark.asyncio
async def test_deploy_executes_update_and_logs_transaction():
    """deploy() must UPDATE resource_units and INSERT inventory_transactions."""
    from src.agents.agent_3_resource.inventory_manager import InventoryManager
    from src.agents.agent_3_resource.models import ResourceUnit

    pool = FakePool()
    inv  = InventoryManager(pool)

    unit = ResourceUnit(
        id=uuid4(),
        resource_type=ResourceType.RESCUE_BOAT,
        name="Boat-Test",
        capacity=15,
        current_location=GeoPoint(latitude=23.80, longitude=90.37),
        base_location=GeoPoint(latitude=23.80, longitude=90.37),
    )

    await inv.deploy(unit, incident_id="INC-001", zone_id="zone-dhaka")

    # Should have executed at least 2 statements: UPDATE + INSERT
    assert len(pool.executed) >= 2
    assert any("UPDATE resource_units" in q for q in pool.executed)
    assert any("INSERT INTO inventory_transactions" in q for q in pool.executed)


@pytest.mark.asyncio
async def test_add_units_inserts_correct_count():
    """add_units(quantity=3) should INSERT 3 rows into resource_units."""
    from src.agents.agent_3_resource.inventory_manager import InventoryManager

    pool = FakePool()
    pool._fetchval_result = 0  # no existing units of this type

    # fetchval for COUNT(*) + fetchval for each INSERT RETURNING id
    insert_ids = [uuid4(), uuid4(), uuid4()]
    call_count = 0

    async def patched_fetchval(query, *args):
        nonlocal call_count
        result = insert_ids[call_count] if call_count < len(insert_ids) else uuid4()
        call_count += 1
        return result

    pool.fetchval = patched_fetchval

    inv = InventoryManager(pool)
    units = await inv.add_units(
        resource_type=ResourceType.MEDICAL_KIT,
        quantity=3,
        location=GeoPoint(latitude=23.81, longitude=90.41),
        notes="Test restock",
    )

    assert len(units) == 3
    for u in units:
        assert u.resource_type == ResourceType.MEDICAL_KIT
        assert u.status == ResourceStatus.AVAILABLE


@pytest.mark.asyncio
async def test_get_available_queries_correct_type():
    """get_available() should pass resource_type value to the query."""
    from src.agents.agent_3_resource.inventory_manager import InventoryManager

    pool = FakePool(rows=[])
    inv  = InventoryManager(pool)

    await inv.get_available(ResourceType.FOOD_SUPPLY)

    # The executed query should filter on resource_type
    assert any("resource_units" in q for q in pool.executed)
    assert any("available" in q for q in pool.executed)


@pytest.mark.asyncio
async def test_log_allocation_inserts_with_correct_fields():
    """log_allocation() should INSERT into resource_allocations."""
    from src.agents.agent_3_resource.inventory_manager import InventoryManager
    from src.agents.agent_3_resource.models import ResourceAllocation

    pool = FakePool()
    inv  = InventoryManager(pool)

    allocation = ResourceAllocation(
        incident_id="INC-TEST",
        zone_id="zone-1",
        zone_name="Test Zone",
        destination=GeoPoint(latitude=24.89, longitude=91.87),
        priority=5,
        urgency="LIFE_THREATENING",
        num_people_affected=30,
        allocated_resources=[{"unit_id": str(uuid4()), "type": "rescue_boat", "name": "B1",
                               "current_location": {"latitude": 24.89, "longitude": 91.87}}],
        partial_allocation=False,
        requires_medical=True,
    )

    await inv.log_allocation(allocation)

    assert any("INSERT INTO resource_allocations" in q for q in pool.executed)

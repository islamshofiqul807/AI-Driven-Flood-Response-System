"""
Resource Allocation Algorithm — the brain of Agent 3.

Rules (from spec):
  LIFE_THREATENING : 2 boats + 1 medical_team + 2 medical_kits
  URGENT (medical) : 1 boat + 1 medical_team + 1 medical_kit
  URGENT (no med)  : 1 boat + 1 food_supply + 1 water_supply
  MODERATE         : 1 food_supply + 1 water_supply

Resources are scored by Haversine distance — closest wins.
If a resource type is exhausted, partial_allocation = True and the
deficit is logged but the allocation still proceeds.
"""
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

from shared.geo_utils import haversine_km

from .inventory_manager import InventoryManager
from .models import (
    GeoPoint,
    ResourceAllocation,
    ResourceType,
    ResourceUnit,
    UrgencyLevel,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Allocation rules table
# ---------------------------------------------------------------------------

AllocationRule = Dict[ResourceType, int]   # type → minimum count needed

RULES: Dict[str, AllocationRule] = {
    "LIFE_THREATENING": {
        ResourceType.RESCUE_BOAT:  2,
        ResourceType.MEDICAL_TEAM: 1,
        ResourceType.MEDICAL_KIT:  2,
    },
    "URGENT_MEDICAL": {
        ResourceType.RESCUE_BOAT:  1,
        ResourceType.MEDICAL_TEAM: 1,
        ResourceType.MEDICAL_KIT:  1,
    },
    "URGENT_SUPPLY": {
        ResourceType.RESCUE_BOAT:  1,
        ResourceType.FOOD_SUPPLY:  1,
        ResourceType.WATER_SUPPLY: 1,
    },
    "MODERATE": {
        ResourceType.FOOD_SUPPLY:  1,
        ResourceType.WATER_SUPPLY: 1,
    },
}


def _pick_rule(urgency: str, medical_need: bool) -> AllocationRule:
    if urgency == UrgencyLevel.LIFE_THREATENING:
        return RULES["LIFE_THREATENING"]
    if urgency == UrgencyLevel.URGENT:
        return RULES["URGENT_MEDICAL"] if medical_need else RULES["URGENT_SUPPLY"]
    return RULES["MODERATE"]


def _closest(
    units: List[ResourceUnit],
    destination: GeoPoint,
    count: int,
) -> Tuple[List[ResourceUnit], bool]:
    """
    Pick up to `count` nearest units from the list.
    Returns (selected_units, was_partial).
    """
    scored = sorted(
        units,
        key=lambda u: haversine_km(
            u.current_location.latitude,
            u.current_location.longitude,
            destination.latitude,
            destination.longitude,
        ),
    )
    selected = scored[:count]
    partial = len(selected) < count
    if partial:
        logger.warning(
            "Resource shortfall: needed %d but only %d available",
            count, len(selected),
        )
    return selected, partial


class ResourceAllocator:
    """Stateless allocator — state lives in DB via InventoryManager."""

    def __init__(self, inventory: InventoryManager):
        self.inventory = inventory

    async def allocate(self, incident: dict) -> Optional[ResourceAllocation]:
        """
        Main entry point.

        incident dict keys (from Agent 2 distress_queue payload):
            incident_id, zone_id, zone_name, location {latitude, longitude},
            urgency, num_people, medical_need, priority
        """
        urgency     = incident.get("urgency", UrgencyLevel.MODERATE)
        medical_need = incident.get("medical_need", False)
        destination  = GeoPoint(**incident["location"])
        rule         = _pick_rule(urgency, medical_need)

        allocated_units: List[dict] = []
        partial = False

        # For each resource type required, fetch available units and pick closest
        for rtype, needed_count in rule.items():
            available = await self.inventory.get_available(rtype)
            selected, is_partial = _closest(available, destination, needed_count)
            if is_partial:
                partial = True
                logger.warning(
                    "Partial allocation for %s — needed %d %s, got %d",
                    incident.get("incident_id"), needed_count, rtype.value, len(selected),
                )

            for unit in selected:
                await self.inventory.deploy(
                    unit=unit,
                    incident_id=incident["incident_id"],
                    zone_id=incident["zone_id"],
                )
                allocated_units.append({
                    "unit_id":          str(unit.id),
                    "type":             unit.resource_type.value,
                    "name":             unit.name,
                    "current_location": {
                        "latitude":  unit.current_location.latitude,
                        "longitude": unit.current_location.longitude,
                    },
                })

        if not allocated_units:
            logger.error(
                "Zero resources available for incident %s — skipping",
                incident.get("incident_id"),
            )
            return None

        allocation = ResourceAllocation(
            incident_id=incident["incident_id"],
            zone_id=incident["zone_id"],
            zone_name=incident.get("zone_name", "Unknown Zone"),
            destination=destination,
            priority=incident.get("priority", 3),
            urgency=urgency,
            num_people_affected=incident.get("num_people", 0),
            allocated_resources=allocated_units,
            partial_allocation=partial,
            requires_medical=medical_need or urgency == UrgencyLevel.LIFE_THREATENING,
            notes=(
                "Partial allocation — some resource types exhausted."
                if partial else "Full allocation."
            ),
        )

        await self.inventory.log_allocation(allocation)
        return allocation

    async def process_distress_queue(
        self, incidents: List[dict]
    ) -> List[ResourceAllocation]:
        """
        Process a batch of incidents sorted by priority (highest first).
        Returns list of ResourceAllocation objects published to Agent 4.
        """
        sorted_incidents = sorted(
            incidents,
            key=lambda x: x.get("priority", 1),
            reverse=True,
        )
        results = []
        for inc in sorted_incidents:
            allocation = await self.allocate(inc)
            if allocation:
                results.append(allocation)
        return results

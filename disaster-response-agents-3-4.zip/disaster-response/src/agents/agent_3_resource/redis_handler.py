"""
Redis handler for Agent 3.
Subscribes to:  distress_queue  (from Agent 2)
Publishes to:   dispatch_order  (to Agent 4)
                inventory_update (to Dashboard)
                agent_status    (heartbeat)
"""
import asyncio
import logging
from datetime import datetime, timezone

from shared.message_protocol import (
    AgentMessage,
    HeartbeatMessage,
    listen_for_messages,
    log_message_to_db,
    publish_message,
)

from .allocator import ResourceAllocator
from .inventory_manager import InventoryManager

logger = logging.getLogger(__name__)

AGENT_ID = "agent_3_resource"


class Agent3RedisHandler:
    def __init__(self, redis_client, db_pool):
        self.redis   = redis_client
        self.db      = db_pool
        self.inventory = InventoryManager(db_pool)
        self.allocator = ResourceAllocator(self.inventory)
        self._start_time = datetime.now(timezone.utc)
        self._last_action: str = "initialized"

    # ------------------------------------------------------------------
    # Subscriber
    # ------------------------------------------------------------------

    async def start_listening(self):
        """Start the distress_queue subscriber (run as asyncio task)."""
        await listen_for_messages(
            self.redis, "distress_queue", self._handle_distress_queue
        )

    async def _handle_distress_queue(self, envelope: AgentMessage):
        logger.info(
            "Received distress_queue from %s | zone=%s | priority=%d",
            envelope.sender_agent, envelope.zone_id, envelope.priority,
        )
        self._last_action = f"received distress_queue zone={envelope.zone_id}"

        incidents: list = envelope.payload.get("incidents", [])
        if not incidents:
            logger.warning("distress_queue payload has no incidents — skipping")
            return

        allocations = await self.allocator.process_distress_queue(incidents)

        for allocation in allocations:
            await self._publish_dispatch_order(allocation, envelope)
            await self._publish_inventory_update()

    # ------------------------------------------------------------------
    # Publishers
    # ------------------------------------------------------------------

    async def _publish_dispatch_order(self, allocation, source_envelope: AgentMessage):
        message = AgentMessage(
            sender_agent=AGENT_ID,
            receiver_agent="agent_4_dispatch",
            message_type="dispatch_order",
            zone_id=allocation.zone_id,
            priority=allocation.priority,
            payload=allocation.model_dump(mode="json"),
        )
        await publish_message(self.redis, "dispatch_order", message)
        await log_message_to_db(self.db, message)
        self._last_action = f"published dispatch_order zone={allocation.zone_id}"
        logger.info(
            "Published dispatch_order for incident %s (%d resources)",
            allocation.incident_id, len(allocation.allocated_resources),
        )

    async def _publish_inventory_update(self):
        snapshot = await self.inventory.snapshot()
        message = AgentMessage(
            sender_agent=AGENT_ID,
            receiver_agent="all",
            message_type="inventory_update",
            payload=snapshot.model_dump(mode="json"),
        )
        await publish_message(self.redis, "inventory_update", message)

    async def publish_heartbeat(self):
        """Publish a heartbeat on agent_status every 30 seconds."""
        while True:
            uptime = (datetime.now(timezone.utc) - self._start_time).total_seconds()
            hb = HeartbeatMessage(
                agent_id=AGENT_ID,
                uptime_seconds=uptime,
                last_action=self._last_action,
            )
            msg = AgentMessage(
                sender_agent=AGENT_ID,
                receiver_agent="all",
                message_type="heartbeat",
                payload=hb.model_dump(mode="json"),
            )
            await publish_message(self.redis, "agent_status", msg)
            await asyncio.sleep(30)

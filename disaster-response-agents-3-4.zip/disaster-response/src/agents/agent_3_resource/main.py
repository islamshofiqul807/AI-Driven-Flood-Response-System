"""
Agent 3 — Resource Management
FastAPI service on port 8003 (mapped from 8000 inside Docker).
"""
import asyncio
import logging
import os
import sys
from contextlib import asynccontextmanager
from typing import Optional

import asyncpg
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from redis import asyncio as aioredis

# Make shared/ importable when running outside Docker
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../../../"))

from .inventory_manager import InventoryManager
from .models import (
    GeoPoint,
    ResourceAllocation,
    ResourceType,
    RestockRequest,
    RestockResponse,
)
from .redis_handler import Agent3RedisHandler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("agent_3_resource")

# ---------------------------------------------------------------------------
# Configuration (read from .env via environment)
# ---------------------------------------------------------------------------
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://disaster_admin:disaster123@localhost:5432/disaster_response",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
AGENT_PORT = int(os.getenv("AGENT_PORT", "8000"))

# ---------------------------------------------------------------------------
# App state
# ---------------------------------------------------------------------------
db_pool: Optional[asyncpg.Pool] = None
redis_client = None
handler: Optional[Agent3RedisHandler] = None


# ---------------------------------------------------------------------------
# Seed data — realistic Dhaka/Bangladesh depot locations
# ---------------------------------------------------------------------------
SEED_RESOURCES = [
    # Rescue boats — BIWTA river stations
    {"type": "rescue_boat", "name": "Boat Mirpur-1",     "capacity": 15, "lat": 23.8041, "lon": 90.3654},
    {"type": "rescue_boat", "name": "Boat Mirpur-2",     "capacity": 15, "lat": 23.8041, "lon": 90.3654},
    {"type": "rescue_boat", "name": "Boat Sadarghat-1",  "capacity": 20, "lat": 23.7104, "lon": 90.4074},
    {"type": "rescue_boat", "name": "Boat Sadarghat-2",  "capacity": 20, "lat": 23.7104, "lon": 90.4074},
    {"type": "rescue_boat", "name": "Boat Sylhet-1",     "capacity": 12, "lat": 24.8949, "lon": 91.8687},
    {"type": "rescue_boat", "name": "Boat Sylhet-2",     "capacity": 12, "lat": 24.8949, "lon": 91.8687},
    {"type": "rescue_boat", "name": "Boat Sirajganj-1",  "capacity": 18, "lat": 24.4534, "lon": 89.7007},
    {"type": "rescue_boat", "name": "Boat Sunamganj-1",  "capacity": 10, "lat": 25.0715, "lon": 91.3953},

    # Medical teams — major hospitals
    {"type": "medical_team", "name": "MedTeam Dhaka-1",     "capacity": 50, "lat": 23.7465, "lon": 90.3760},
    {"type": "medical_team", "name": "MedTeam Dhaka-2",     "capacity": 40, "lat": 23.7376, "lon": 90.3957},
    {"type": "medical_team", "name": "MedTeam Sylhet-1",    "capacity": 30, "lat": 24.8998, "lon": 91.8710},
    {"type": "medical_team", "name": "MedTeam Sirajganj-1", "capacity": 25, "lat": 24.4600, "lon": 89.7100},

    # Medical kits — depots
    {"type": "medical_kit", "name": "Kit-Depot-Dhaka-1",    "capacity": 100, "lat": 23.8103, "lon": 90.4125},
    {"type": "medical_kit", "name": "Kit-Depot-Dhaka-2",    "capacity": 100, "lat": 23.7500, "lon": 90.3800},
    {"type": "medical_kit", "name": "Kit-Depot-Sylhet",     "capacity":  60, "lat": 24.9000, "lon": 91.8700},
    {"type": "medical_kit", "name": "Kit-Depot-Chittagong", "capacity":  80, "lat": 22.3569, "lon": 91.7832},

    # Food supply depots
    {"type": "food_supply", "name": "Food-Mohakhali-1",  "capacity": 500, "lat": 23.7781, "lon": 90.4070},
    {"type": "food_supply", "name": "Food-Mohakhali-2",  "capacity": 500, "lat": 23.7781, "lon": 90.4070},
    {"type": "food_supply", "name": "Food-Sylhet",       "capacity": 300, "lat": 24.8900, "lon": 91.8650},
    {"type": "food_supply", "name": "Food-Sirajganj",    "capacity": 400, "lat": 24.4500, "lon": 89.7050},
    {"type": "food_supply", "name": "Food-Sunamganj",    "capacity": 250, "lat": 25.0700, "lon": 91.3900},

    # Water supply depots
    {"type": "water_supply", "name": "Water-Mohakhali-1", "capacity": 1000, "lat": 23.7781, "lon": 90.4070},
    {"type": "water_supply", "name": "Water-Mohakhali-2", "capacity": 1000, "lat": 23.7781, "lon": 90.4070},
    {"type": "water_supply", "name": "Water-Sylhet",      "capacity":  600, "lat": 24.8900, "lon": 91.8650},
    {"type": "water_supply", "name": "Water-Sirajganj",   "capacity":  800, "lat": 24.4500, "lon": 89.7050},
    {"type": "water_supply", "name": "Water-Sunamganj",   "capacity":  500, "lat": 25.0700, "lon": 91.3900},
]


async def seed_inventory_if_empty(pool: asyncpg.Pool):
    count = await pool.fetchval("SELECT COUNT(*) FROM resource_units")
    if count and count > 0:
        logger.info("Inventory already seeded (%d units) — skipping", count)
        return

    logger.info("Seeding inventory with %d resources…", len(SEED_RESOURCES))
    for r in SEED_RESOURCES:
        await pool.execute(
            """
            INSERT INTO resource_units
                (resource_type, name, status, capacity, current_location, base_location)
            VALUES ($1, $2, 'available', $3,
                    ST_SetSRID(ST_MakePoint($5, $4), 4326),
                    ST_SetSRID(ST_MakePoint($5, $4), 4326))
            """,
            r["type"], r["name"], r["capacity"], r["lat"], r["lon"],
        )
    logger.info("Seed complete.")


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool, redis_client, handler

    # Connect DB
    db_pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=10)
    logger.info("PostgreSQL connected")

    # Seed data
    await seed_inventory_if_empty(db_pool)

    # Connect Redis
    redis_client = await aioredis.from_url(REDIS_URL, decode_responses=True)
    logger.info("Redis connected")

    # Start Redis handler
    handler = Agent3RedisHandler(redis_client, db_pool)
    asyncio.create_task(handler.start_listening())
    asyncio.create_task(handler.publish_heartbeat())
    logger.info("Agent 3 listening on distress_queue")

    yield

    # Cleanup
    await db_pool.close()
    await redis_client.aclose()


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Agent 3 — Resource Management",
    description="Disaster response resource inventory and allocation service.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
async def root():
    return {
        "agent": "agent_3_resource",
        "version": "1.0.0",
        "port": AGENT_PORT,
        "subscribes_to": ["distress_queue"],
        "publishes_to":  ["dispatch_order", "inventory_update", "agent_status"],
    }


@app.get("/health")
async def health():
    try:
        await db_pool.fetchval("SELECT 1")
        await redis_client.ping()
        return {"status": "healthy", "db": "ok", "redis": "ok"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.get("/inventory")
async def get_inventory():
    inv = InventoryManager(db_pool)
    snapshot = await inv.snapshot()
    return snapshot.model_dump(mode="json")


@app.get("/inventory/{resource_type}")
async def get_inventory_by_type(resource_type: ResourceType):
    inv = InventoryManager(db_pool)
    units = await inv.get_all(resource_type)
    return {
        "resource_type": resource_type.value,
        "count": len(units),
        "units": [u.model_dump(mode="json") for u in units],
    }


@app.post("/inventory/restock", response_model=RestockResponse)
async def restock(request: RestockRequest):
    inv = InventoryManager(db_pool)
    units = await inv.add_units(
        resource_type=request.resource_type,
        quantity=request.quantity,
        location=request.location,
        notes=request.notes,
    )
    # Publish inventory update
    snapshot = await inv.snapshot()
    from shared.message_protocol import AgentMessage, publish_message
    msg = AgentMessage(
        sender_agent="agent_3_resource",
        receiver_agent="all",
        message_type="inventory_update",
        payload=snapshot.model_dump(mode="json"),
    )
    await publish_message(redis_client, "inventory_update", msg)

    return RestockResponse(
        added=len(units),
        message=f"Added {len(units)} × {request.resource_type.value}",
        units=[u.model_dump(mode="json") for u in units],
    )


@app.get("/allocations")
async def get_allocations(limit: int = 20):
    rows = await db_pool.fetch(
        """
        SELECT id, timestamp, incident_id, zone_name, urgency,
               num_people_affected,
               jsonb_array_length(allocated_units) AS resource_count,
               partial_allocation
        FROM resource_allocations
        ORDER BY timestamp DESC
        LIMIT $1
        """,
        limit,
    )
    return [dict(r) for r in rows]


@app.get("/allocations/{allocation_id}")
async def get_allocation(allocation_id: str):
    row = await db_pool.fetchrow(
        "SELECT * FROM resource_allocations WHERE id = $1::uuid",
        allocation_id,
    )
    if not row:
        raise HTTPException(status_code=404, detail="Allocation not found")
    return dict(row)


@app.post("/trigger")
async def trigger_allocation(incident: dict):
    """Manually trigger allocation for a single incident dict (for testing)."""
    if not handler:
        raise HTTPException(status_code=503, detail="Handler not ready")
    allocation = await handler.allocator.allocate(incident)
    if not allocation:
        raise HTTPException(status_code=422, detail="No resources available")
    await handler._publish_dispatch_order(allocation, None)
    return allocation.model_dump(mode="json")


@app.get("/status")
async def status():
    if not handler:
        return {"status": "starting"}
    uptime = (
        datetime.now(timezone.utc) - handler._start_time
    ).total_seconds()
    return {
        "status":       "running",
        "uptime_s":     uptime,
        "last_action":  handler._last_action,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn
    from datetime import timezone, datetime  # noqa: F811

    uvicorn.run(
        "src.agents.agent_3_resource.main:app",
        host="0.0.0.0",
        port=AGENT_PORT,
        reload=False,
    )

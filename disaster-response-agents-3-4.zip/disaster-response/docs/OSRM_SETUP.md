# OSRM Setup — Bangladesh Road Data

Agent 4 uses a self-hosted OSRM instance with real Bangladesh OpenStreetMap
road data. This is a **one-time setup** — do it before your first
`docker-compose up`.

---

## Step 1 — Create the data directory

```bash
mkdir -p osrm-data
cd osrm-data
```

## Step 2 — Download Bangladesh OSM data (~90 MB)

```bash
wget https://download.geofabrik.de/asia/bangladesh-latest.osm.pbf
```

## Step 3 — Pre-process for OSRM (run from project root)

```bash
# Extract (car routing profile)
docker run -t -v "${PWD}/osrm-data:/data" \
  ghcr.io/project-osrm/osrm-backend \
  osrm-extract -p /opt/car.lua /data/bangladesh-latest.osm.pbf

# Partition
docker run -t -v "${PWD}/osrm-data:/data" \
  ghcr.io/project-osrm/osrm-backend \
  osrm-partition /data/bangladesh-latest.osrm

# Customize
docker run -t -v "${PWD}/osrm-data:/data" \
  ghcr.io/project-osrm/osrm-backend \
  osrm-customize /data/bangladesh-latest.osrm
```

This produces several `.osrm.*` files in `osrm-data/`.
The full process takes ~3–5 minutes on a normal laptop.

## Step 4 — Start everything

```bash
docker-compose up -d
```

Verify OSRM is running:

```bash
curl "http://localhost:5000/route/v1/driving/90.4074,23.7104;91.8687,24.8949?overview=false"
# Should return {"code":"Ok", ...}
```

---

## Skipping OSRM (unit tests / demo without real routing)

Agent 4 has a straight-line fallback — if OSRM is unreachable it computes
distance via Haversine and assumes 30 km/h average road speed.
All unit tests use this fallback automatically (OSRM is mocked).

To start only the DB + Redis + agents without OSRM:

```bash
docker-compose up -d postgres redis agent1 agent2 agent3 agent4
```

Agent 4 will log a warning and use fallback routing until OSRM comes up.

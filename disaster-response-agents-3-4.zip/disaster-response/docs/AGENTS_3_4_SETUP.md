# Agents 3 & 4 — Setup & Usage Guide

This document supplements the main README with setup instructions
specific to Agent 3 (Resource Management) and Agent 4 (Dispatch Optimization).

---

## Quick Start (Agents 3 & 4 only)

```bash
# 1. Start infrastructure + both new agents
docker-compose up -d postgres redis agent3 agent4

# 2. Check all agents are healthy
python scripts/check_health.py

# 3. Run the demo
python scripts/run_demo.py
```

---

## Step-by-step setup

### 1. Database schemas

The `database/` folder is mounted into PostgreSQL and runs automatically on first start.
Files execute in alphabetical order:

| File | Creates |
|---|---|
| `003_resource_schema.sql` | `resource_units`, `inventory_transactions`, `resource_allocations`, `inventory_summary` view |
| `004_dispatch_schema.sql` | `dispatch_routes`, `team_routes`, `active_dispatches` view |
| `005_agent_messages.sql`  | `agent_messages` (shared inter-agent log) |

If you need to re-run them manually:
```bash
docker exec -i disaster_postgres psql -U disaster_admin -d disaster_response \
    < database/003_resource_schema.sql
```

### 2. OSRM road data (one-time, ~5 min)

See `docs/OSRM_SETUP.md` for full instructions. Short version:

```bash
mkdir osrm-data && cd osrm-data
wget https://download.geofabrik.de/asia/bangladesh-latest.osm.pbf
# Then run the 3 docker osrm-extract / osrm-partition / osrm-customize commands
cd ..
docker-compose up -d osrm
```

If OSRM is not set up, Agent 4 automatically falls back to straight-line
distance estimation (30 km/h road speed assumed). This is fine for the prototype.

### 3. Seed inventory

Agent 3 auto-seeds 26 resource units on first start (if the table is empty):
- 8 rescue boats  (BIWTA river stations: Mirpur, Sadarghat, Sylhet, Sirajganj, Sunamganj)
- 4 medical teams (Dhaka Medical, Mitford, Sylhet MAG Osmani, Sirajganj)
- 4 medical kit depots
- 5 food supply depots
- 5 water supply depots

---

## Scripts

### `scripts/check_health.py`
Verify all 4 agents + OSRM are running before a demo.
```bash
python scripts/check_health.py
```

### `scripts/run_demo.py`
Simulate 3 realistic flood scenarios end-to-end.
```bash
python scripts/run_demo.py                        # all 3 scenarios
python scripts/run_demo.py --scenario mirpur_flood  # one scenario
python scripts/run_demo.py --delay 3               # slower, for live narration
```
Scenarios: `mirpur_flood`, `sylhet_rising`, `sirajganj_breach`

### `scripts/trigger_incident.py`
Manually fire a single incident at Agent 3 (useful during development).
```bash
python scripts/trigger_incident.py --urgency LIFE_THREATENING --zone mirpur
python scripts/trigger_incident.py --urgency MODERATE --zone sylhet --people 200
```

### `scripts/reset_inventory.py`
Reset deployed resources back to available for a clean demo re-run.
```bash
python scripts/reset_inventory.py          # reset statuses only
python scripts/reset_inventory.py --hard   # also clear routes and messages
```

### `tests/integration/test_full_chain.py`
End-to-end integration test. Publishes real Redis messages and verifies
the full chain via DB queries.
```bash
python tests/integration/test_full_chain.py
```

---

## API reference

### Agent 3 — `http://localhost:8003`

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Health check (DB + Redis) |
| `/inventory` | GET | Current inventory snapshot (all types) |
| `/inventory/{type}` | GET | Units of one resource type |
| `/inventory/restock` | POST | Add resources manually |
| `/allocations` | GET | Recent allocation history |
| `/allocations/{id}` | GET | Single allocation detail |
| `/trigger` | POST | Manually trigger allocation (testing) |
| `/status` | GET | Agent uptime + last action |

Restock request body:
```json
{
  "resource_type": "rescue_boat",
  "quantity": 2,
  "location": {"latitude": 23.8041, "longitude": 90.3654},
  "notes": "Extra boats from Chittagong"
}
```

### Agent 4 — `http://localhost:8004`

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Health check (DB + Redis + OSRM URL) |
| `/routes` | GET | Active dispatch routes |
| `/routes/{id}` | GET | Route with all team details |
| `/routes/{id}/geojson` | GET | GeoJSON FeatureCollection for map rendering |
| `/teams` | GET | All active team statuses |
| `/teams/{id}/status` | POST | Update team status (arrived, returning) |
| `/trigger` | POST | Manually trigger route computation (testing) |
| `/status` | GET | Agent uptime + OSRM URL |

---

## Redis channels

| Channel | Publisher | Subscriber | Message |
|---|---|---|---|
| `flood_alert` | Agent 1 | Agent 2 | `EnvironmentalAlert` |
| `distress_queue` | Agent 2 | Agent 3 | `{incidents: [...]}` |
| `dispatch_order` | Agent 3 | Agent 4 | `ResourceAllocation` |
| `route_assignment` | Agent 4 | Dashboard | `RouteAssignment` |
| `inventory_update` | Agent 3 | Dashboard | `InventorySnapshot` |
| `agent_status` | All | Dashboard | `HeartbeatMessage` |

---

## Running tests (no Docker needed)

```bash
pip install fastapi pydantic asyncpg redis httpx pytest pytest-asyncio

# Unit tests — Agent 3
pytest src/agents/agent_3_resource/tests/ -v

# Unit tests — Agent 4
pytest src/agents/agent_4_dispatch/tests/ -v

# All tests
pytest
```

---

## Integration checklist (from spec)

### Agent 3
- [x] FastAPI on port 8003
- [x] PostgreSQL connection
- [x] Redis subscribe `distress_queue`
- [x] Redis publish `dispatch_order`
- [x] Redis publish `inventory_update`
- [x] `AgentMessage` envelope on all messages
- [x] `GET /health` → 200
- [x] `GET /inventory` → snapshot
- [x] `POST /inventory/restock`
- [x] Allocation deducts from inventory
- [x] Transactions logged to `inventory_transactions`
- [x] Schema runs on existing PostgreSQL
- [x] Docker container Dockerfile

### Agent 4
- [x] FastAPI on port 8004
- [x] PostgreSQL connection
- [x] Redis subscribe `dispatch_order`
- [x] Redis publish `route_assignment`
- [x] `AgentMessage` envelope on all messages
- [x] `GET /health` → 200
- [x] `GET /routes` → active routes
- [x] `GET /routes/{id}/geojson` → GeoJSON
- [x] `GET /teams` → team statuses
- [x] Road routes via OSRM
- [x] Boat routes via straight-line + speed
- [x] Route safety check vs flood zones
- [x] Docker container Dockerfile
- [x] OSRM service in docker-compose

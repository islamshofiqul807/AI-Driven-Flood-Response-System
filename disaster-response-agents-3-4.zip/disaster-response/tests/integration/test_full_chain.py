"""
Integration Test — Full Agent Chain
====================================
Simulates the complete pipeline:
  1. Publish a fake flood_alert  (as Agent 1 would)
  2. Publish a fake distress_queue (as Agent 2 would)
  3. Agent 3 allocates resources → publishes dispatch_order
  4. Agent 4 computes routes    → publishes route_assignment
  5. Verify agent_messages table has all 4 message types

Run AFTER docker-compose up (postgres + redis must be reachable):
    python tests/integration/test_full_chain.py

Or with real services on localhost:
    DATABASE_URL=postgresql://disaster_admin:disaster123@localhost:5432/disaster_response \
    REDIS_URL=redis://localhost:6379 \
    python tests/integration/test_full_chain.py
"""
import asyncio
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../"))

import asyncpg
from redis import asyncio as aioredis

from shared.message_protocol import AgentMessage, publish_message

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://disaster_admin:disaster123@localhost:5432/disaster_response",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# ── Colour helpers ────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

def ok(msg):    print(f"{GREEN}  ✔ {msg}{RESET}")
def info(msg):  print(f"{CYAN}  → {msg}{RESET}")
def warn(msg):  print(f"{YELLOW}  ⚠ {msg}{RESET}")
def fail(msg):  print(f"{RED}  ✘ {msg}{RESET}")
def header(msg): print(f"\n{BOLD}{msg}{RESET}")


# ── Fake payloads ─────────────────────────────────────────────────────────────

INCIDENT_ID = f"INT-TEST-{uuid.uuid4().hex[:6].upper()}"
ZONE_ID     = "zone-dhaka-mirpur"

FLOOD_ALERT_PAYLOAD = {
    "alert_id":     str(uuid.uuid4()),
    "zone_id":      ZONE_ID,
    "zone_name":    "Dhaka Mirpur (Integration Test)",
    "severity":     "critical",
    "center":       {"latitude": 23.8041, "longitude": 90.3654},
    "radius_km":    3.5,
    "flood_depth_m": 1.8,
    "affected_population": 12000,
    "timestamp":    datetime.now(timezone.utc).isoformat(),
    "source":       "integration_test",
}

DISTRESS_QUEUE_PAYLOAD = {
    "incidents": [
        {
            "incident_id": INCIDENT_ID,
            "zone_id":     ZONE_ID,
            "zone_name":   "Dhaka Mirpur (Integration Test)",
            "location":    {"latitude": 23.8041, "longitude": 90.3654},
            "urgency":     "LIFE_THREATENING",
            "num_people":  35,
            "medical_need": True,
            "priority":    5,
            "source_messages": ["Test incident for integration validation"],
        }
    ]
}


# ── Subscriber helpers ────────────────────────────────────────────────────────

async def wait_for_message(redis, channel: str, timeout: int = 30) -> dict | None:
    """Subscribe to channel and return first message payload within timeout seconds."""
    pubsub = redis.pubsub()
    await pubsub.subscribe(channel)
    deadline = time.time() + timeout
    async for raw in pubsub.listen():
        if raw["type"] == "message":
            data = json.loads(raw["data"])
            await pubsub.unsubscribe(channel)
            return data
        if time.time() > deadline:
            await pubsub.unsubscribe(channel)
            return None
    return None


# ── Checks ────────────────────────────────────────────────────────────────────

async def check_agent_messages(db, expected_types: list[str]) -> bool:
    """Verify that all expected message types landed in agent_messages table."""
    rows = await db.fetch(
        "SELECT DISTINCT message_type FROM agent_messages ORDER BY message_type"
    )
    found = {r["message_type"] for r in rows}
    all_ok = True
    for mtype in expected_types:
        if mtype in found:
            ok(f"agent_messages has message_type='{mtype}'")
        else:
            warn(f"agent_messages MISSING message_type='{mtype}'")
            all_ok = False
    return all_ok


async def check_inventory_deployed(db) -> bool:
    """Verify at least some resource_units were marked deployed."""
    count = await db.fetchval(
        "SELECT COUNT(*) FROM resource_units WHERE status = 'deployed'"
    )
    if count and count > 0:
        ok(f"{count} resource unit(s) marked as deployed")
        return True
    warn("No resource units were marked deployed — allocation may have failed")
    return False


async def check_dispatch_routes(db) -> bool:
    """Verify at least one dispatch_route was created."""
    count = await db.fetchval("SELECT COUNT(*) FROM dispatch_routes")
    if count and count > 0:
        ok(f"{count} dispatch route(s) created in dispatch_routes table")
        return True
    warn("No dispatch routes found in DB")
    return False


async def check_team_routes(db) -> bool:
    """Verify team_routes were created with geometry."""
    rows = await db.fetch(
        "SELECT unit_name, transport_mode, eta_minutes, distance_km "
        "FROM team_routes ORDER BY eta_minutes"
    )
    if not rows:
        warn("No team_routes found")
        return False
    ok(f"{len(rows)} team route(s) created:")
    for r in rows:
        print(f"       {r['unit_name']} | {r['transport_mode']} | "
              f"{r['distance_km']:.1f} km | ETA {r['eta_minutes']:.0f} min")
    return True


# ── Main ──────────────────────────────────────────────────────────────────────

async def run():
    print(f"\n{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}  Disaster Response — Full Chain Integration Test{RESET}")
    print(f"{BOLD}{'='*60}{RESET}")

    # 1. Connect
    header("Step 1: Connect to infrastructure")
    try:
        db = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=3)
        ok("PostgreSQL connected")
    except Exception as e:
        fail(f"PostgreSQL connection failed: {e}")
        return False

    try:
        redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
        await redis.ping()
        ok("Redis connected")
    except Exception as e:
        fail(f"Redis connection failed: {e}")
        return False

    # 2. Verify agents are reachable (optional HTTP check)
    header("Step 2: Verify agent_messages baseline")
    before_count = await db.fetchval("SELECT COUNT(*) FROM agent_messages") or 0
    info(f"agent_messages rows before test: {before_count}")

    # 3. Subscribe listeners BEFORE publishing (avoid race)
    header("Step 3: Set up subscribers")
    redis_listen_dispatch = await aioredis.from_url(REDIS_URL, decode_responses=True)
    redis_listen_route    = await aioredis.from_url(REDIS_URL, decode_responses=True)

    dispatch_task = asyncio.create_task(
        wait_for_message(redis_listen_dispatch, "dispatch_order", timeout=25)
    )
    route_task = asyncio.create_task(
        wait_for_message(redis_listen_route, "route_assignment", timeout=45)
    )
    ok("Subscribed to dispatch_order and route_assignment channels")

    # 4. Publish flood_alert (Agent 1's job)
    header("Step 4: Publish flood_alert (simulating Agent 1)")
    flood_msg = AgentMessage(
        sender_agent="agent_1_environmental",
        receiver_agent="agent_2_distress",
        message_type="flood_alert",
        zone_id=ZONE_ID,
        priority=5,
        payload=FLOOD_ALERT_PAYLOAD,
    )
    await publish_message(redis, "flood_alert", flood_msg)
    ok(f"flood_alert published → zone={ZONE_ID}")
    await asyncio.sleep(1)

    # 5. Publish distress_queue (Agent 2's job)
    header("Step 5: Publish distress_queue (simulating Agent 2)")
    distress_msg = AgentMessage(
        sender_agent="agent_2_distress",
        receiver_agent="agent_3_resource",
        message_type="distress_queue",
        zone_id=ZONE_ID,
        priority=5,
        payload=DISTRESS_QUEUE_PAYLOAD,
    )
    await publish_message(redis, "distress_queue", distress_msg)
    ok(f"distress_queue published with 1 LIFE_THREATENING incident (id={INCIDENT_ID})")

    # 6. Wait for Agent 3 → dispatch_order
    header("Step 6: Wait for Agent 3 → dispatch_order")
    dispatch_data = await dispatch_task
    if dispatch_data:
        envelope = AgentMessage(**dispatch_data)
        alloc = envelope.payload
        ok(f"dispatch_order received | incident={alloc.get('incident_id')}")
        ok(f"  Resources allocated: {len(alloc.get('allocated_resources', []))}")
        ok(f"  Partial: {alloc.get('partial_allocation')}")
        ok(f"  Requires medical: {alloc.get('requires_medical')}")
    else:
        warn("Timed out waiting for dispatch_order — Agent 3 may not be running")
        info("Continuing to check DB state anyway…")

    # 7. Wait for Agent 4 → route_assignment
    header("Step 7: Wait for Agent 4 → route_assignment")
    route_data = await route_task
    if route_data:
        envelope = AgentMessage(**route_data)
        ra = envelope.payload
        ok(f"route_assignment received | incident={ra.get('incident_id')}")
        ok(f"  Teams dispatched: {len(ra.get('teams', []))}")
        ok(f"  Total ETA: {ra.get('total_eta_minutes', 0):.0f} min")
        ok(f"  Safety score: {ra.get('route_safety_score', 0):.0%}")
    else:
        warn("Timed out waiting for route_assignment — Agent 4 may not be running")

    # 8. Database verification
    header("Step 8: Database state verification")
    await asyncio.sleep(2)  # let any final DB writes land

    results = await asyncio.gather(
        check_agent_messages(db, [
            "flood_alert", "distress_queue", "dispatch_order", "route_assignment"
        ]),
        check_inventory_deployed(db),
        check_dispatch_routes(db),
        check_team_routes(db),
    )

    # 9. Summary
    header("Summary")
    passed = sum(1 for r in results if r)
    total  = len(results)
    if passed == total:
        print(f"\n{GREEN}{BOLD}  ALL {total} CHECKS PASSED ✔{RESET}\n")
        print(f"  The full agent chain is working correctly.")
        print(f"  Agent 1 → Agent 2 → Agent 3 → Agent 4 → Dashboard\n")
    else:
        print(f"\n{YELLOW}{BOLD}  {passed}/{total} checks passed.{RESET}")
        print(f"  Some agents may not be running — see warnings above.")
        print(f"  DB checks confirm the schema is intact.\n")

    await db.close()
    await redis.aclose()
    await redis_listen_dispatch.aclose()
    await redis_listen_route.aclose()
    return passed == total


if __name__ == "__main__":
    success = asyncio.run(run())
    sys.exit(0 if success else 1)

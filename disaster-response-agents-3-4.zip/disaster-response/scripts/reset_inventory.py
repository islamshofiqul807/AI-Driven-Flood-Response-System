"""
Reset Inventory Script
======================
Resets all deployed/returning resource units back to 'available'
and clears allocations/routes for a clean demo restart.

Usage:
    python scripts/reset_inventory.py            # soft reset (status only)
    python scripts/reset_inventory.py --hard     # wipe allocations + routes too
"""
import argparse
import asyncio
import os
import sys

try:
    import asyncpg
except ImportError:
    print("pip install asyncpg")
    sys.exit(1)

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://disaster_admin:disaster123@localhost:5432/disaster_response",
)

G = "\033[92m"; Y = "\033[93m"; R = "\033[91m"; B = "\033[1m"; X = "\033[0m"


async def reset(hard: bool = False):
    print(f"\n{B}Disaster Response — Inventory Reset{X}")
    print("─" * 45)

    db = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=3)

    # Count current state
    rows = await db.fetch(
        "SELECT status, COUNT(*) AS n FROM resource_units GROUP BY status"
    )
    print("  Before reset:")
    for r in rows:
        print(f"    {r['status']:<15} {r['n']} units")

    # Soft reset — mark all non-available units as available
    updated = await db.execute(
        """
        UPDATE resource_units
        SET status               = 'available',
            assigned_zone_id     = NULL,
            assigned_incident_id = NULL,
            deployed_at          = NULL,
            updated_at           = NOW()
        WHERE status IN ('deployed', 'returning')
        """
    )
    count = int(updated.split()[-1])
    print(f"\n  {G}✔ {count} unit(s) reset to 'available'{X}")

    if hard:
        print(f"\n  {Y}Hard reset: clearing allocations, routes, messages…{X}")
        await db.execute("DELETE FROM team_routes")
        await db.execute("DELETE FROM dispatch_routes")
        await db.execute("DELETE FROM resource_allocations")
        await db.execute("DELETE FROM inventory_transactions WHERE direction = 'allocated'")
        await db.execute("DELETE FROM agent_messages WHERE message_type IN ('distress_queue','dispatch_order','route_assignment')")
        print(f"  {G}✔ Allocation, route, and message tables cleared{X}")

    # Count after
    rows = await db.fetch(
        "SELECT status, COUNT(*) AS n FROM resource_units GROUP BY status"
    )
    print("\n  After reset:")
    for r in rows:
        print(f"    {r['status']:<15} {r['n']} units")

    await db.close()
    print(f"\n  {G}{B}Ready for next demo run.{X}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--hard", action="store_true",
                        help="Also clear allocation, route, and message tables")
    args = parser.parse_args()
    asyncio.run(reset(hard=args.hard))

"""
Quick trigger script — manually fire an incident at Agent 3's /trigger endpoint.
Useful when testing without the full Docker stack.

Usage:
    # Life-threatening incident in Mirpur
    python scripts/trigger_incident.py --urgency LIFE_THREATENING --zone mirpur

    # Moderate supply incident in Sylhet
    python scripts/trigger_incident.py --urgency MODERATE --zone sylhet --people 150
"""
import argparse
import asyncio
import json
import os
import uuid

try:
    import httpx
except ImportError:
    print("pip install httpx")
    import sys; sys.exit(1)

AGENT3_URL = os.getenv("AGENT3_URL", "http://localhost:8003")
AGENT4_URL = os.getenv("AGENT4_URL", "http://localhost:8004")

ZONE_COORDS = {
    "mirpur":    {"lat": 23.8041, "lon": 90.3654, "name": "Dhaka Mirpur"},
    "sadarghat": {"lat": 23.7104, "lon": 90.4074, "name": "Dhaka Sadarghat"},
    "sylhet":    {"lat": 24.8949, "lon": 91.8687, "name": "Sylhet City"},
    "sirajganj": {"lat": 24.4534, "lon": 89.7007, "name": "Sirajganj"},
    "sunamganj": {"lat": 25.0715, "lon": 91.3953, "name": "Sunamganj"},
}

G = "\033[92m"; R = "\033[91m"; C = "\033[96m"; B = "\033[1m"; X = "\033[0m"


async def trigger(args):
    zone = ZONE_COORDS.get(args.zone, ZONE_COORDS["mirpur"])
    incident = {
        "incident_id":  f"MANUAL-{uuid.uuid4().hex[:6].upper()}",
        "zone_id":      f"zone-{args.zone}",
        "zone_name":    zone["name"],
        "location":    {"latitude": zone["lat"], "longitude": zone["lon"]},
        "urgency":      args.urgency,
        "num_people":   args.people,
        "medical_need": args.urgency in ("LIFE_THREATENING", "URGENT"),
        "priority":     5 if args.urgency == "LIFE_THREATENING" else
                        3 if args.urgency == "URGENT" else 1,
    }

    print(f"\n{B}Triggering incident at Agent 3{X}")
    print(f"  Zone:    {zone['name']}")
    print(f"  Urgency: {args.urgency}")
    print(f"  People:  {args.people}")
    print(f"  URL:     {AGENT3_URL}/trigger\n")

    async with httpx.AsyncClient(timeout=15.0) as client:
        try:
            resp = await client.post(f"{AGENT3_URL}/trigger", json=incident)
            if resp.status_code == 200:
                data = resp.json()
                print(f"{G}✔ Allocation created{X}")
                print(f"  Allocation ID: {data.get('allocation_id')}")
                print(f"  Resources:     {len(data.get('allocated_resources', []))}")
                print(f"  Partial:       {data.get('partial_allocation')}")
                print(f"  Requires med:  {data.get('requires_medical')}")
                print()
                for r in data.get("allocated_resources", []):
                    print(f"    • {r['name']:<30} [{r['type']}]")
            else:
                print(f"{R}✘ HTTP {resp.status_code}: {resp.text}{X}")
        except httpx.ConnectError:
            print(f"{R}✘ Cannot connect to Agent 3 at {AGENT3_URL}{X}")
            print(f"  Start with: docker-compose up -d agent3")

    # Also show inventory after
    print(f"\n{C}Current inventory (Agent 3):{X}")
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(f"{AGENT3_URL}/inventory")
            if resp.status_code == 200:
                data = resp.json()
                for rtype, counts in data.get("resources", {}).items():
                    avail   = counts["available"]
                    deployed = counts["deployed"]
                    total   = counts["total"]
                    bar = "█" * avail + "░" * deployed
                    print(f"  {rtype:<20} {bar:<15} {avail}/{total} available")
        except Exception:
            pass
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manually trigger an incident")
    parser.add_argument("--urgency",  choices=["LIFE_THREATENING","URGENT","MODERATE"],
                        default="LIFE_THREATENING")
    parser.add_argument("--zone",     choices=list(ZONE_COORDS.keys()), default="mirpur")
    parser.add_argument("--people",   type=int, default=40)
    asyncio.run(trigger(parser.parse_args()))

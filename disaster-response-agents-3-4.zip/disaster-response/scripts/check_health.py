"""
Health Check Script — verify all agents are up before the demo.

Usage:
    python scripts/check_health.py
"""
import asyncio
import os
import sys

try:
    import httpx
except ImportError:
    print("pip install httpx")
    sys.exit(1)

AGENTS = {
    "Agent 1 — Environmental": "http://localhost:8001/health",
    "Agent 2 — Distress":      "http://localhost:8002/health",
    "Agent 3 — Resource":      "http://localhost:8003/health",
    "Agent 4 — Dispatch":      "http://localhost:8004/health",
}
OSRM = "http://localhost:5000/route/v1/driving/90.4074,23.7104;91.8687,24.8949?overview=false"

G = "\033[92m"
R = "\033[91m"
Y = "\033[93m"
B = "\033[1m"
X = "\033[0m"


async def check(name: str, url: str, timeout: float = 5.0) -> bool:
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
        if resp.status_code == 200:
            data = resp.json()
            status = data.get("status", "ok")
            print(f"  {G}✔ {name:<35}{X} {status}")
            return True
        else:
            print(f"  {R}✘ {name:<35}{X} HTTP {resp.status_code}")
            return False
    except Exception as e:
        print(f"  {R}✘ {name:<35}{X} {type(e).__name__}: {e}")
        return False


async def main():
    print(f"\n{B}Disaster Response — Agent Health Check{X}")
    print("─" * 55)

    results = []
    for name, url in AGENTS.items():
        ok = await check(name, url)
        results.append(ok)

    print("\n" + "─" * 55)
    print(f"{B}OSRM Road Router{X}")
    osrm_ok = await check("OSRM — Bangladesh roads", OSRM, timeout=8.0)
    results.append(osrm_ok)

    print("\n" + "─" * 55)
    passed = sum(results)
    total  = len(results)
    if passed == total:
        print(f"\n{G}{B}  All {total} services healthy. Ready for demo! ✔{X}\n")
    else:
        print(f"\n{Y}{B}  {passed}/{total} services healthy.{X}")
        if not results[-1]:
            print(f"  {Y}OSRM not running — Agent 4 will use straight-line fallback.{X}")
        down = [name for (name, _), ok in zip(AGENTS.items(), results[:-1]) if not ok]
        for name in down:
            print(f"  {R}Start with: docker-compose up -d{X}")
        print()
    return passed == total


if __name__ == "__main__":
    ok = asyncio.run(main())
    sys.exit(0 if ok else 1)

"""
Demo Simulation Script — Disaster Response System
==================================================
Simulates a realistic flood event in Dhaka for your defence presentation.

Usage:
    # Standard 3-scenario demo (recommended for presentation)
    python scripts/run_demo.py

    # Single scenario
    python scripts/run_demo.py --scenario mirpur_flood

    # With delay between steps (for live narration)
    python scripts/run_demo.py --delay 3

Requirements:
    docker-compose up -d postgres redis agent3 agent4
    (Agents 1 & 2 can be simulated by this script)
"""
import argparse
import asyncio
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../"))

try:
    import asyncpg
    from redis import asyncio as aioredis
    from shared.message_protocol import AgentMessage, publish_message
except ImportError:
    print("Missing dependencies. Run: pip install asyncpg redis")
    sys.exit(1)

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://disaster_admin:disaster123@localhost:5432/disaster_response",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

# ── Terminal colours ──────────────────────────────────────────────────────────
B = "\033[1m"
G = "\033[92m"
Y = "\033[93m"
C = "\033[96m"
R = "\033[91m"
M = "\033[95m"
X = "\033[0m"

def box(title: str, colour: str = C):
    w = 60
    print(f"\n{colour}{B}{'─'*w}{X}")
    print(f"{colour}{B}  {title}{X}")
    print(f"{colour}{B}{'─'*w}{X}")

def step(n: int, msg: str):
    print(f"\n{B}[Step {n}]{X} {msg}")

def ok(msg):   print(f"  {G}✔ {msg}{X}")
def info(msg): print(f"  {C}→ {msg}{X}")
def warn(msg): print(f"  {Y}⚠ {msg}{X}")


# ── Scenario definitions ──────────────────────────────────────────────────────

SCENARIOS = {
    "mirpur_flood": {
        "title":       "Mirpur Flash Flood — Severity: CRITICAL",
        "zone_id":     "zone-dhaka-mirpur",
        "zone_name":   "Dhaka Mirpur",
        "lat": 23.8041, "lon": 90.3654,
        "severity":    "critical",
        "depth_m":     1.8,
        "population":  12_000,
        "incidents": [
            {
                "urgency":     "LIFE_THREATENING",
                "num_people":  35,
                "medical_need": True,
                "priority":    5,
                "description": "Families stranded on rooftops, Mirpur-10 metro area",
            },
            {
                "urgency":     "URGENT",
                "num_people":  80,
                "medical_need": False,
                "priority":    3,
                "description": "Ground floor residents evacuating, food/water needed",
            },
        ],
    },
    "sylhet_rising": {
        "title":       "Sylhet River Rising — Severity: HIGH",
        "zone_id":     "zone-sylhet-city",
        "zone_name":   "Sylhet City Centre",
        "lat": 24.8949, "lon": 91.8687,
        "severity":    "high",
        "depth_m":     1.2,
        "population":  8_500,
        "incidents": [
            {
                "urgency":     "LIFE_THREATENING",
                "num_people":  20,
                "medical_need": True,
                "priority":    5,
                "description": "Elderly patients at risk, Sylhet Boro Bazar area",
            },
        ],
    },
    "sirajganj_breach": {
        "title":       "Sirajganj Jamuna Embankment Breach — Severity: CRITICAL",
        "zone_id":     "zone-sirajganj-north",
        "zone_name":   "Sirajganj North",
        "lat": 24.4534, "lon": 89.7007,
        "severity":    "critical",
        "depth_m":     2.3,
        "population":  5_200,
        "incidents": [
            {
                "urgency":     "LIFE_THREATENING",
                "num_people":  60,
                "medical_need": True,
                "priority":    5,
                "description": "Char (river island) residents cut off, embankment breached",
            },
            {
                "urgency":     "MODERATE",
                "num_people":  200,
                "medical_need": False,
                "priority":    2,
                "description": "Upstream villages — supply distribution required",
            },
        ],
    },
}


# ── Core publisher ────────────────────────────────────────────────────────────

async def run_scenario(
    redis, db,
    scenario: dict,
    step_delay: float = 1.5,
) -> dict:
    """
    Run one flood scenario end-to-end.
    Returns summary dict with counts and ETAs.
    """
    zone_id   = scenario["zone_id"]
    zone_name = scenario["zone_name"]
    lat, lon  = scenario["lat"], scenario["lon"]

    # Build incidents with IDs
    incidents = []
    for i, raw in enumerate(scenario["incidents"]):
        incidents.append({
            "incident_id": f"INC-{zone_id.upper()[-6:]}-{i+1:02d}",
            "zone_id":     zone_id,
            "zone_name":   zone_name,
            "location":   {"latitude": lat, "longitude": lon},
            "urgency":     raw["urgency"],
            "num_people":  raw["num_people"],
            "medical_need": raw["medical_need"],
            "priority":    raw["priority"],
        })
        info(f"Incident {i+1}: {raw['urgency']} — {raw['description']}")

    await asyncio.sleep(step_delay)

    # Step A — flood_alert (Agent 1 → Agent 2)
    step(1, f"Agent 1 publishes flood_alert → {zone_name}")
    flood_msg = AgentMessage(
        sender_agent="agent_1_environmental",
        receiver_agent="agent_2_distress",
        message_type="flood_alert",
        zone_id=zone_id,
        priority=5,
        payload={
            "alert_id":           str(uuid.uuid4()),
            "zone_id":            zone_id,
            "zone_name":          zone_name,
            "severity":           scenario["severity"],
            "center":             {"latitude": lat, "longitude": lon},
            "radius_km":          4.0,
            "flood_depth_m":      scenario["depth_m"],
            "affected_population": scenario["population"],
            "timestamp":          datetime.now(timezone.utc).isoformat(),
            "source":             "sentinel_1_sar",
        },
    )
    await publish_message(redis, "flood_alert", flood_msg)
    ok(f"flood_alert published  [severity={scenario['severity']}, depth={scenario['depth_m']}m]")
    await asyncio.sleep(step_delay)

    # Step B — distress_queue (Agent 2 → Agent 3)
    step(2, f"Agent 2 publishes distress_queue ({len(incidents)} incident(s))")
    distress_msg = AgentMessage(
        sender_agent="agent_2_distress",
        receiver_agent="agent_3_resource",
        message_type="distress_queue",
        zone_id=zone_id,
        priority=5,
        payload={"incidents": incidents},
    )
    await publish_message(redis, "distress_queue", distress_msg)
    ok(f"distress_queue published with {len(incidents)} prioritised incident(s)")
    await asyncio.sleep(step_delay * 2)  # give Agent 3 time to process

    # Step C — read back what Agent 3 produced
    step(3, "Checking Agent 3 output (resource_allocations table)")
    alloc_rows = await db.fetch(
        """
        SELECT incident_id, urgency, num_people_affected,
               jsonb_array_length(allocated_units) AS unit_count,
               partial_allocation, requires_medical
        FROM resource_allocations
        WHERE zone_id = $1
        ORDER BY timestamp DESC
        LIMIT $2
        """,
        zone_id, len(incidents),
    )
    total_units = 0
    for row in alloc_rows:
        total_units += row["unit_count"] or 0
        partial = " (PARTIAL)" if row["partial_allocation"] else ""
        ok(
            f"  {row['incident_id']} | {row['urgency']} | "
            f"{row['unit_count']} resources{partial}"
        )
    await asyncio.sleep(step_delay)

    # Step D — read what Agent 4 produced
    step(4, "Checking Agent 4 output (dispatch_routes + team_routes)")
    await asyncio.sleep(step_delay)  # extra wait for Agent 4 OSRM calls
    team_rows = await db.fetch(
        """
        SELECT tr.unit_name, tr.resource_type, tr.transport_mode,
               tr.eta_minutes, tr.distance_km, tr.status
        FROM team_routes tr
        JOIN dispatch_routes dr ON dr.id = tr.dispatch_id
        WHERE dr.zone_id = $1
        ORDER BY tr.eta_minutes
        """,
        zone_id,
    )
    if team_rows:
        ok(f"{len(team_rows)} team route(s) computed:")
        for t in team_rows:
            mode_icon = "🚤" if t["transport_mode"] == "waterway" else "🚑"
            print(
                f"    {mode_icon}  {t['unit_name']:<25} "
                f"{t['distance_km']:5.1f} km  "
                f"ETA {t['eta_minutes']:5.0f} min"
            )
        max_eta = max(t["eta_minutes"] for t in team_rows)
        ok(f"Slowest ETA (full deployment): {max_eta:.0f} min")
    else:
        warn("No team routes found — Agent 4 may still be computing or not running")

    # Step E — message log
    step(5, "Agent message log (agent_messages table)")
    msg_rows = await db.fetch(
        """
        SELECT message_type, sender_agent, receiver_agent, priority
        FROM agent_messages
        WHERE zone_id = $1
        ORDER BY timestamp
        """,
        zone_id,
    )
    for m in msg_rows:
        print(
            f"    {C}{m['sender_agent']:<28}{X} → "
            f"{m['receiver_agent']:<28} "
            f"[{m['message_type']}]"
        )

    return {
        "zone":         zone_name,
        "incidents":    len(incidents),
        "allocations":  len(alloc_rows),
        "teams":        len(team_rows),
        "total_units":  total_units,
        "max_eta_min":  max(t["eta_minutes"] for t in team_rows) if team_rows else None,
        "messages":     len(msg_rows),
    }


# ── Main ──────────────────────────────────────────────────────────────────────

async def main(args):
    box("DISASTER RESPONSE SYSTEM — LIVE DEMO", colour=M)
    print(f"  {B}Database:{X} {DATABASE_URL.split('@')[-1]}")
    print(f"  {B}Redis:   {X} {REDIS_URL}")

    # Connect
    try:
        db    = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=3)
        redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
        await redis.ping()
        ok("Infrastructure connected")
    except Exception as e:
        warn(f"Connection error: {e}")
        warn("Make sure docker-compose services are running:")
        print("    docker-compose up -d postgres redis agent3 agent4")
        return

    # Pick scenarios
    if args.scenario:
        if args.scenario not in SCENARIOS:
            print(f"Unknown scenario '{args.scenario}'. Available: {list(SCENARIOS.keys())}")
            return
        selected = {args.scenario: SCENARIOS[args.scenario]}
    else:
        selected = SCENARIOS

    summaries = []
    for key, scenario in selected.items():
        box(f"SCENARIO: {scenario['title']}", colour=Y)
        summary = await run_scenario(redis, db, scenario, step_delay=args.delay)
        summaries.append(summary)
        if len(selected) > 1:
            print(f"\n  {C}Pausing 3 s before next scenario…{X}")
            await asyncio.sleep(3)

    # Final summary table
    box("DEMO COMPLETE — SUMMARY", colour=G)
    print(f"  {'Zone':<30} {'Incidents':>9} {'Teams':>6} {'Max ETA':>9} {'Messages':>9}")
    print(f"  {'─'*30} {'─'*9} {'─'*6} {'─'*9} {'─'*9}")
    for s in summaries:
        eta = f"{s['max_eta_min']:.0f} min" if s["max_eta_min"] else "pending"
        print(
            f"  {s['zone']:<30} {s['incidents']:>9} "
            f"{s['teams']:>6} {eta:>9} {s['messages']:>9}"
        )

    print(f"\n  {G}{B}System demonstrated end-to-end agent coordination.{X}")
    print(f"  Agent 1 → flood detection")
    print(f"  Agent 2 → distress classification")
    print(f"  Agent 3 → resource allocation (closest-first, urgency-based)")
    print(f"  Agent 4 → route optimisation (OSRM roads + boat estimation)")
    print()

    await db.close()
    await redis.aclose()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Disaster Response Demo")
    parser.add_argument(
        "--scenario",
        choices=list(SCENARIOS.keys()),
        default=None,
        help="Run a single scenario (default: all three)",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=1.5,
        help="Seconds to pause between steps (default: 1.5)",
    )
    asyncio.run(main(parser.parse_args()))
